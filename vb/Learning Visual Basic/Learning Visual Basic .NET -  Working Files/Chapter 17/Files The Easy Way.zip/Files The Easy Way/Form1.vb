﻿Imports System.IO.File

Public Class Form1
    ' Load any previously saved messages.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Exists("Log.txt") Then
            ' Read the lines into the ListBox.
            Dim lines() As String = ReadAllLines("Log.txt")
            For Each line As String In lines
                lstMessages.Items.Add(line)
            Next line

            ' Scroll to the bottom.
            lstMessages.SelectedIndex = lstMessages.Items.Count - 1
        End If
    End Sub

    ' Add a new message to the log file and the ListBox.
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        Dim message As String = Date.Now & ": " & txtMessage.Text

        AppendAllText("Log.txt", message & vbCrLf)
        lstMessages.Items.Add(message)

        ' Scroll to the bottom.
        lstMessages.SelectedIndex = lstMessages.Items.Count - 1
        txtMessage.Clear()
        txtMessage.Focus()
    End Sub
End Class
