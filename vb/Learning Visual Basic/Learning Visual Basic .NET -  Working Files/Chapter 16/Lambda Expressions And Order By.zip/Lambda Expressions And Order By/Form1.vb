﻿Public Class Form1
    ' List people, their ages, and their prices sorted by age.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim people As New List(Of Person)()
        people.Add(New Person() With {.FirstName = "Valerie", .LastName = "Ramirez", .Age = 12})
        people.Add(New Person() With {.FirstName = "Ian", .LastName = "Moreno", .Age = 17})
        people.Add(New Person() With {.FirstName = "Lorraine", .LastName = "Huff", .Age = 21})
        people.Add(New Person() With {.FirstName = "Elmer", .LastName = "Rice", .Age = 4})
        people.Add(New Person() With {.FirstName = "Julio", .LastName = "Ball", .Age = 3})
        people.Add(New Person() With {.FirstName = "Sharon", .LastName = "Rodgers", .Age = 7})
        people.Add(New Person() With {.FirstName = "Vicki", .LastName = "Torres", .Age = 15})
        people.Add(New Person() With {.FirstName = "Eileen", .LastName = "Cooper", .Age = 16})
        people.Add(New Person() With {.FirstName = "Miguel", .LastName = "Frazier", .Age = 9})
        people.Add(New Person() With {.FirstName = "Jackie", .LastName = "Hardy", .Age = 20})
        people.Add(New Person() With {.FirstName = "Gretchen", .LastName = "Olson", .Age = 11})
        people.Add(New Person() With {.FirstName = "Lila", .LastName = "Bennett", .Age = 61})

        ' Lambda expression to convert age into admission price.
        Dim admission_price = Function(age As Integer) As Decimal
                                  If age <= 5 Then Return 5
                                  If age <= 17 Then Return 7.5
                                  If age <= 59 Then Return 12.5
                                  Return 5
                              End Function

        ' Order by age.
        Dim by_age =
            From per As Person In people
            Select Name = per.FirstName & " " & per.LastName,
                Age = per.Age,
                Price = admission_price(per.Age)
            Order By Age

        For Each obj In by_age
            lstByAge.Items.Add(obj.Age & " " & obj.Price.ToString("C") & " " & obj.Name)
        Next obj

        ' Order by price.
        Dim by_price =
            From per As Person In people
            Select Name = per.FirstName & " " & per.LastName,
                Age = per.Age,
                Price = admission_price(per.Age)
            Order By Price

        For Each obj In by_price
            lstByPrice.Items.Add(obj.Price.ToString("C") & " " & obj.Age & " " & obj.Name)
        Next obj
    End Sub
End Class
