﻿Public Class EventsForm

    Private Sub btnMain_Click(sender As Object, e As EventArgs) Handles btnMain.Click
        TheMainForm.Show()
        TheMainForm.Focus()
    End Sub

    Private Sub btnSchedule_Click(sender As Object, e As EventArgs) Handles btnSchedule.Click
        TheScheduleForm.Show()
        TheScheduleForm.Focus()
    End Sub

    Private Sub EventsForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        e.Cancel = True
        Me.Hide()
    End Sub
End Class