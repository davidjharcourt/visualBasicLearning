﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSetTimes = New System.Windows.Forms.Button()
        Me.txtLastWrite = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtLastAccess = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtCreated = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.btnBrowse = New System.Windows.Forms.Button()
        Me.btnGetTime = New System.Windows.Forms.Button()
        Me.txtFile = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ofdFile = New System.Windows.Forms.OpenFileDialog()
        Me.SuspendLayout()
        '
        'btnSetTimes
        '
        Me.btnSetTimes.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnSetTimes.Location = New System.Drawing.Point(154, 149)
        Me.btnSetTimes.Name = "btnSetTimes"
        Me.btnSetTimes.Size = New System.Drawing.Size(75, 23)
        Me.btnSetTimes.TabIndex = 23
        Me.btnSetTimes.Text = "Set Times"
        Me.btnSetTimes.UseVisualStyleBackColor = True
        '
        'txtLastWrite
        '
        Me.txtLastWrite.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLastWrite.Location = New System.Drawing.Point(75, 123)
        Me.txtLastWrite.Name = "txtLastWrite"
        Me.txtLastWrite.Size = New System.Drawing.Size(296, 20)
        Me.txtLastWrite.TabIndex = 22
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 126)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(35, 13)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Write:"
        '
        'txtLastAccess
        '
        Me.txtLastAccess.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtLastAccess.Location = New System.Drawing.Point(75, 97)
        Me.txtLastAccess.Name = "txtLastAccess"
        Me.txtLastAccess.Size = New System.Drawing.Size(296, 20)
        Me.txtLastAccess.TabIndex = 20
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(57, 13)
        Me.Label2.TabIndex = 19
        Me.Label2.Text = "Accessed:"
        '
        'txtCreated
        '
        Me.txtCreated.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtCreated.Location = New System.Drawing.Point(75, 71)
        Me.txtCreated.Name = "txtCreated"
        Me.txtCreated.Size = New System.Drawing.Size(296, 20)
        Me.txtCreated.TabIndex = 18
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 74)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(47, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Created:"
        '
        'btnBrowse
        '
        Me.btnBrowse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnBrowse.Location = New System.Drawing.Point(296, 10)
        Me.btnBrowse.Name = "btnBrowse"
        Me.btnBrowse.Size = New System.Drawing.Size(75, 23)
        Me.btnBrowse.TabIndex = 16
        Me.btnBrowse.Text = "Browse"
        Me.btnBrowse.UseVisualStyleBackColor = True
        '
        'btnGetTime
        '
        Me.btnGetTime.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnGetTime.Location = New System.Drawing.Point(154, 36)
        Me.btnGetTime.Name = "btnGetTime"
        Me.btnGetTime.Size = New System.Drawing.Size(75, 23)
        Me.btnGetTime.TabIndex = 15
        Me.btnGetTime.Text = "Get Times"
        Me.btnGetTime.UseVisualStyleBackColor = True
        '
        'txtFile
        '
        Me.txtFile.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtFile.Location = New System.Drawing.Point(44, 10)
        Me.txtFile.Name = "txtFile"
        Me.txtFile.Size = New System.Drawing.Size(246, 20)
        Me.txtFile.TabIndex = 14
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(26, 13)
        Me.Label1.TabIndex = 13
        Me.Label1.Text = "File:"
        '
        'ofdFile
        '
        Me.ofdFile.FileName = "OpenFileDialog1"
        Me.ofdFile.Filter = "All Files|*.*"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(383, 183)
        Me.Controls.Add(Me.btnSetTimes)
        Me.Controls.Add(Me.txtLastWrite)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtLastAccess)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtCreated)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.btnBrowse)
        Me.Controls.Add(Me.btnGetTime)
        Me.Controls.Add(Me.txtFile)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "File Dates And Times"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnSetTimes As System.Windows.Forms.Button
    Friend WithEvents txtLastWrite As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtLastAccess As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCreated As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents btnBrowse As System.Windows.Forms.Button
    Friend WithEvents btnGetTime As System.Windows.Forms.Button
    Friend WithEvents txtFile As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ofdFile As System.Windows.Forms.OpenFileDialog

End Class
