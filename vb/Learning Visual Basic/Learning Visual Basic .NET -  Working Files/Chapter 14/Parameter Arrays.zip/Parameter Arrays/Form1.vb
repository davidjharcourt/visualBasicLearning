﻿Public Class Form1
    ' Run some tests.
    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        ShowGrade("Alice", 100, 90, 97, 80)
        ShowGrade("Bob", 61, 43, 55, 70)
        ShowGrade("Cindy")
        ShowGrade("Dean", 75, 90, 84, 81)
    End Sub
End Class
