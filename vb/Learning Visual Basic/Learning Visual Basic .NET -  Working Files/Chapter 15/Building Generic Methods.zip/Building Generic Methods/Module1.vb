﻿Module Module1
    ' "Invert" a list.
    Public Function InvertList(Of T)(items As List(Of T)) As List(Of T)
        Dim result As New List(Of T)()
        Do While items.Count > 0
            ' Move the first item into the result list.
            result.Add(items(0))
            items.RemoveAt(0)

            ' Make sure the list isn't empty.
            If items.Count = 0 Then Exit Do

            ' Move the larst item into the result list.
            result.Add(items(items.Count - 1))
            items.RemoveAt(items.Count - 1)
        Loop

        ' Return the result list.
        Return result
    End Function
End Module
