﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Make some students.
        Dim students As New List(Of Student)()
        students.Add(New Student() With {.Name = "Ann", .Grade = "A"})
        students.Add(New Student() With {.Name = "Bill", .Grade = "B"})
        students.Add(New Student() With {.Name = "Cindy", .Grade = "D"})
        students.Add(New Student() With {.Name = "Dean", .Grade = "F"})
        students.Add(New Student() With {.Name = "Ellen", .Grade = "A"})
        students.Add(New Student() With {.Name = "Fred", .Grade = "C"})
        students.Add(New Student() With {.Name = "Gina", .Grade = "B"})
        students.Add(New Student() With {.Name = "Herb", .Grade = "D"})
        students.Add(New Student() With {.Name = "Ivy", .Grade = "B"})

        ' Select A students.
        Dim a_students =
            From stu As Student In students
            Where stu.Grade = "A"
            Select stu
        For Each stu As Student In a_students
            lstA.Items.Add(stu.Name & " (" & stu.Grade & ")")
        Next stu

        ' Select A, B, and C students.
        Dim abc_students =
            From stu As Student In students
            Where stu.Grade = "A" Or stu.Grade = "B" Or stu.Grade = "C"
            Select stu
        For Each stu As Student In abc_students
            lstAbc.Items.Add(stu.Name & " (" & stu.Grade & ")")
        Next stu

        ' Select failing students.
        Dim failing_students =
            From stu As Student In students
            Where stu.Grade = "F"
            Select stu
        For Each stu As Student In failing_students
            lstFailing.Items.Add(stu.Name & " (" & stu.Grade & ")")
        Next stu
    End Sub
End Class
