﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        TheMainForm = Me
        TheScheduleForm = New ScheduleForm()
        TheEventsForm = New EventsForm()
    End Sub

    Private Sub btnSchedule_Click(sender As Object, e As EventArgs) Handles btnSchedule.Click
        TheScheduleForm.Show()
        TheScheduleForm.Focus()
    End Sub

    Private Sub btnEvents_Click(sender As Object, e As EventArgs) Handles btnEvents.Click
        TheEventsForm.Show()
        TheEventsForm.Focus()
    End Sub
End Class
