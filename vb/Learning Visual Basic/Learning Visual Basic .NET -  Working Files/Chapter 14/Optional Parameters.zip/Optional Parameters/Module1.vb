﻿Module Module1

    Public Sub PlaceOrder(item As String, Optional delivery_date As Date = #10/2/1890#)
        ' See if we have a real date.
        If delivery_date < Date.Today Then
            ' This is a bogus date. Create the real one.
            delivery_date = Date.Today.AddDays(7)
        End If

        ' Display the message.
        MessageBox.Show("Your " & item & " will be delivered on " &
            delivery_date.ToLongDateString())
    End Sub

End Module
