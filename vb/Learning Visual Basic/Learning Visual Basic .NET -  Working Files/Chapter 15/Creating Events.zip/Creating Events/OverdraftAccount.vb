﻿Public Class OverdraftAccount

    ' Raised if balance would go between $0 and -$100.
    Public Event Overdraft()

    ' Raised if balance would go below -$100.
    Public Event Overdrawn()

    ' The Balance property.
    Private _Balance As Decimal
    Public Property Balance As Decimal
        Get
            Return _Balance
        End Get
        Set(value As Decimal)
            If value < -100 Then
                ' Value too low. Raise the Overdrawn event.
                RaiseEvent Overdrawn()
            Else
                ' Update the balance.
                _Balance = value

                ' If the value is below 0, raise the Overdraft event.
                If value < 0 Then RaiseEvent Overdraft()
            End If
        End Set
    End Property

    ' Add the amount of money to the balance.
    Public Sub Credit(amount As Decimal)
        Balance += amount
    End Sub

    ' Remove the amount of money from the balance.
    Public Sub Debit(amount As Decimal)
        Balance -= amount
    End Sub


End Class
