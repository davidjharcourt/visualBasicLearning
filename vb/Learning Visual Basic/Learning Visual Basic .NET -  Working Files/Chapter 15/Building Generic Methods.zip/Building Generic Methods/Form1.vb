﻿Public Class Form1
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Invert some letters.
        Dim letters = New List(Of Char)()
        For Each letter As Char In "ABCDE"
            letters.Add(letter)
        Next letter
        Dim inverted_letters As List(Of Char) = InvertList(letters)
        Dim letter_string As String = ""
        For Each letter As Char In inverted_letters
            letter_string &= letter
        Next letter
        txtLetters.Text = letter_string

        ' Invert some numbers.
        Dim numbers = New List(Of Integer)()
        For i As Integer = 1 To 8
            numbers.Add(i)
        Next i
        Dim inverted_numbers As List(Of Integer) = InvertList(numbers)
        Dim number_string As String = ""
        For Each number As String In inverted_numbers
            number_string &= number
        Next number
        txtNumbers.Text = number_string
    End Sub
End Class
