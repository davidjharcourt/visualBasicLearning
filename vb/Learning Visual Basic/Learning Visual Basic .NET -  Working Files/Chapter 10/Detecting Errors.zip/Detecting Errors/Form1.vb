﻿Public Class Form1
    ' Calculate A \ B.
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        ' To display the value Infinity, pick values that make
        ' A / B very large. For example, set A = 1e30 and B = 1e-30.
        '
        ' The "e" in 1e30 means "exponent" so 1e30 means 1 x 10 to the 30th
        ' power or 1 followed by 30 zeros. Similarly 1e-30 means 1 x 10
        ' to the -30th power or 1 / (1 followed by 30 zeros).
        '
        ' So 1e30 / 1e-30 = 1e60, which is too big to fit in a Single.
        '
        ' Alternatively you can just type:
        '       A = 1000000000000000000000000000000
        '       B = 0.0000000000000000000000000000001

        ' Get the user's inputs.
        Dim a, b As Single

        If Not Single.TryParse(txtA.Text, a) Then
            MessageBox.Show("A must be a single")
            txtA.Focus()
            Return
        End If

        If Not Single.TryParse(txtB.Text, b) Then
            MessageBox.Show("B must be a single")
            txtB.Focus()
            Return
        End If

        If b = 0 Then
            MessageBox.Show("B must not be 0")
            txtB.Focus()
            Return
        End If

        ' Calculate the result.
        Dim result As Single = a / b

        ' Display the result.
        txtResult.Text = result
    End Sub
End Class
