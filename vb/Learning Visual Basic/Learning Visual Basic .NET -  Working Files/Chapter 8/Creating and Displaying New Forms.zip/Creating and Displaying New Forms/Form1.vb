﻿Public Class Form1

    Private Sub btnNewUser_Click(sender As Object, e As EventArgs) Handles btnNewUser.Click
        Dim new_form As NewUserForm
        new_form = New NewUserForm()
        new_form.Show()
    End Sub

    Private Sub btnNewCustomer_Click(sender As Object, e As EventArgs) Handles btnNewCustomer.Click
        Dim new_form As NewCustomerForm
        new_form = New NewCustomerForm()
        new_form.Show()
    End Sub
End Class
