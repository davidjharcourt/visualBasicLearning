﻿Imports Microsoft.VisualBasic.FileIO

Public Class Form1
    ' Start in the startup directory.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtDirectory.Text = My.Computer.FileSystem.CombinePath(Application.StartupPath, "..\..")
    End Sub

    ' Let the user browse for a folder.
    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        fbdDirectory.SelectedPath = txtDirectory.Text
        If fbdDirectory.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtDirectory.Text = fbdDirectory.SelectedPath
        End If
    End Sub

    ' Search.
    Private Sub btnListFiles_Click(sender As Object, e As EventArgs) Handles btnListFiles.Click
        ' Make a list of search patterns.
        Dim patterns As New List(Of String)()
        For Each pattern As String In clbPatterns.CheckedItems
            patterns.Add(pattern)
        Next pattern

        ' Get the search type.
        Dim search_option As SearchOption = SearchOption.SearchTopLevelOnly
        If chkRecursive.Checked Then search_option = SearchOption.SearchAllSubDirectories

        ' Search.
        lstFiles.Items.Clear()
        For Each filename As String In My.Computer.FileSystem.FindInFiles(
                txtDirectory.Text, txtString.Text,
                chkIgnoreCase.Checked,
                search_option, patterns.ToArray())
            lstFiles.Items.Add(filename)
        Next filename
    End Sub
End Class
