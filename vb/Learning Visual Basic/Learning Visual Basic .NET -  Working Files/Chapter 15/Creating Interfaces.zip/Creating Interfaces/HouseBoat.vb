﻿Public Class HouseBoat
    Inherits Boat
    Implements IHouse

    Public Property NumBedrooms As Integer Implements IHouse.NumBedrooms

    Public Property SquareFeet As Integer Implements IHouse.SquareFeet
End Class
