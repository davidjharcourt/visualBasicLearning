﻿Public Class Form1
    ' Calculate A / B.
    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Try
            ' Get the user's inputs.
            Dim a As Integer = txtA.Text
            Dim b As Integer = txtB.Text

            ' Calculate the result.
            Dim result As Integer = a \ b

            ' Display the result.
            txtResult.Text = result

        Catch ex As InvalidCastException
            ' A number is blank or something like "ten."
            MessageBox.Show("Please enter valid numbers")

        Catch ex As DivideByZeroException
            ' Number B is 0.
            MessageBox.Show("Number B cannot be 0")

        Catch ex As OverflowException
            ' Numbers like 10 billion or -10 billion.
            MessageBox.Show("One of the numbers is too big or too small")

        Catch ex As Exception
            ' Unknown exception.
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
