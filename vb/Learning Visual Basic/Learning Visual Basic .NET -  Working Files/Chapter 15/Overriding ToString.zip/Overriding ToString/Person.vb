﻿Public Class Person
    Public FirstName, LastName, Email As String

    Public Overrides Function ToString() As String
        Return FirstName & " " & LastName & " (" & Email & ")"
    End Function
End Class
