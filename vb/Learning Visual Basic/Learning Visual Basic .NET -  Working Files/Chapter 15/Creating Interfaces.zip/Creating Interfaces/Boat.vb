﻿Public Class Boat
    Public Property HorsePower As Integer
End Class
