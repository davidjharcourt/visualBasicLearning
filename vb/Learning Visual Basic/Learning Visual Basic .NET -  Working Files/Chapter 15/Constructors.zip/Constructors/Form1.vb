﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Create Person objects with different parameters.
        ' The following one doesn't work.
        'Dim person0 As New Person()
        Dim person1 As New Person("Abe", "Lincoln")
        Dim person2 As New Person("George", "Washington", "800-CALL-GEO")
        Dim person3 As New Person("Ben", "Franklin", "800-BOSS-BEN",
            "bennie@inventor.org")

    End Sub
End Class
