﻿Public Class Form1
    ' Make some Student objects.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim student1 As Student = Student.MakeStudent("George", "Washington")
        Dim student2 As Student = Student.MakeStudent("Alex", "Hamilton")
        Dim student3 As Student = Student.MakeStudent("John", "Adams")

        MessageBox.Show("Created " & Student.NumberOfStudents & " students")

        ' The following won't work because the Student constructor is Private.
        'Dim student4 As New Student()
    End Sub
End Class
