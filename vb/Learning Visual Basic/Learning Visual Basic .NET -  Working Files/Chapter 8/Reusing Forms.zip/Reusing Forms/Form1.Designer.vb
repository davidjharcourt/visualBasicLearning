﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnSchedule = New System.Windows.Forms.Button()
        Me.btnEvents = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnSchedule
        '
        Me.btnSchedule.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnSchedule.Location = New System.Drawing.Point(80, 31)
        Me.btnSchedule.Name = "btnSchedule"
        Me.btnSchedule.Size = New System.Drawing.Size(125, 23)
        Me.btnSchedule.TabIndex = 0
        Me.btnSchedule.Text = "Schedule"
        Me.btnSchedule.UseVisualStyleBackColor = True
        '
        'btnEvents
        '
        Me.btnEvents.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnEvents.Location = New System.Drawing.Point(80, 73)
        Me.btnEvents.Name = "btnEvents"
        Me.btnEvents.Size = New System.Drawing.Size(125, 23)
        Me.btnEvents.TabIndex = 1
        Me.btnEvents.Text = "Events"
        Me.btnEvents.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 127)
        Me.Controls.Add(Me.btnEvents)
        Me.Controls.Add(Me.btnSchedule)
        Me.Name = "Form1"
        Me.Text = "0802_Reusing_Forms"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnSchedule As System.Windows.Forms.Button
    Friend WithEvents btnEvents As System.Windows.Forms.Button

End Class
