﻿Public Class AddressDialog

    Private Sub btnOk_Click(sender As Object, e As EventArgs) Handles btnOk.Click
        If txtFirstName.Text.Length = 0 Then
            MessageBox.Show("Please enter a first name", "Enter First Name",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtFirstName.Focus()
        ElseIf txtLastName.Text.Length = 0 Then
            MessageBox.Show("Please enter a last name", "Enter Last Name",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtLastName.Focus()
        ElseIf txtStreet.Text.Length = 0 Then
            MessageBox.Show("Please enter a street address", "Enter Street Address",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtStreet.Focus()
        ElseIf txtCity.Text.Length = 0 Then
            MessageBox.Show("Please enter a city", "Enter City",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtCity.Focus()
        ElseIf txtState.Text.Length = 0 Then
            MessageBox.Show("Please enter a state", "Enter State",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtState.Focus()
        ElseIf txtZip.Text.Length = 0 Then
            MessageBox.Show("Please enter a ZIP code", "Enter ZIP Code",
                MessageBoxButtons.OK, MessageBoxIcon.Exclamation)
            txtZip.Focus()
        Else
            Me.DialogResult = Windows.Forms.DialogResult.OK
        End If
    End Sub
End Class