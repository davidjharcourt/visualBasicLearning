﻿Public Class ScheduleForm

    Private Sub btnMain_Click(sender As Object, e As EventArgs) Handles btnMain.Click
        TheMainForm.Show()
        TheMainForm.Focus()
    End Sub

    Private Sub btnEvents_Click(sender As Object, e As EventArgs) Handles btnEvents.Click
        TheEventsForm.Show()
        TheEventsForm.Focus()
    End Sub

    Private Sub ScheduleForm_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        e.Cancel = True
        Me.Hide()
    End Sub
End Class