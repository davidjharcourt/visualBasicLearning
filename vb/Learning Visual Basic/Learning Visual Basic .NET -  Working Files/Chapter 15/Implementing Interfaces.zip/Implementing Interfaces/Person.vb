﻿Public Class Person
    Public FirstName, LastName As String

    Public Overrides Function ToString() As String
        Return FirstName & " " & LastName
    End Function
End Class
