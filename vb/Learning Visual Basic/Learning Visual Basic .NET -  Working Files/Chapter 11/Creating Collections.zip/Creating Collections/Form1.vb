﻿Public Class Form1
    ' The dictionary.
    Private TheDictionary As New Dictionary(Of String, String)()

    ' Add a value to teh dictionary.
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ' Use either of the following two statements to add the item.
        ' There is a slight difference between the two statements.
        ' To see the difference, try adding two values with the same keys.
        'TheDictionary.Add(txtKey.Text, txtValue.Text)
        TheDictionary(txtKey.Text) = txtValue.Text

        txtKey.Clear()
        txtValue.Clear()
        txtKey.Focus()
    End Sub

    ' Display the value for the entered key.
    Private Sub btnFind_Click(sender As Object, e As EventArgs) Handles btnFind.Click
        If TheDictionary.ContainsKey(txtKey.Text) Then
            ' Get the value.
            txtValue.Text = TheDictionary(txtKey.Text)
        Else
            ' The key isn't present.
            txtValue.Text = "<Not found>"
        End If
    End Sub
End Class
