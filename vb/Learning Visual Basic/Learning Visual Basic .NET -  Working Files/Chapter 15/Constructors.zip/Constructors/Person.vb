﻿Public Class Person
    Public FirstName, LastName, Phone, Email As String

    '' ********************************
    '' Method 1: Multiple constructors.
    '' ********************************
    '' Take FirstName and LastName as parameters.
    'Public Sub New(first_name As String, last_name As String)
    '    ' Save FirstName and LastName.
    '    FirstName = first_name
    '    LastName = last_name
    'End Sub

    '' Take FirstName, LastName, and Phone as parameters.
    'Public Sub New(first_name As String, last_name As String,
    '        new_phone As String)

    '    ' Invoke the previous constructor.
    '    Me.New(first_name, last_name)

    '    ' Save Phone.
    '    Phone = new_phone
    'End Sub

    '' Take FirstName, LastName, Phone, and Email as parameters.
    'Public Sub New(first_name As String, last_name As String,
    '        new_phone As String, new_email As String)

    '    ' Invoke the previous constructor.
    '    Me.New(first_name, last_name, new_phone)

    '    ' Save Email.
    '    Email = new_email
    'End Sub

    ' ***************************************************
    ' Method 2: One constructor with optional parameters.
    ' ***************************************************
    Public Sub New(first_name As String, last_name As String,
            Optional new_phone As String = "", Optional new_email As String = "")

        ' Save all values.
        FirstName = first_name
        LastName = last_name
        Phone = new_phone
        Email = new_email
    End Sub
End Class
