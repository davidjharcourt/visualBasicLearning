﻿Public Class Form1
    ' The stack.
    Private TheStack As New Stack(Of String)()

    ' Add an item to the stack.
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        TheStack.Push(txtValue.Text)
        txtValue.Clear()
        txtValue.Focus()
    End Sub

    ' Empty the stack.
    Private Sub btnEmpty_Click(sender As Object, e As EventArgs) Handles btnEmpty.Click
        lstValues.Items.Clear()

        While TheStack.Count > 0
            lstValues.Items.Add(TheStack.Pop())
        End While
    End Sub
End Class
