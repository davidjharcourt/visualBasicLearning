﻿Public Class Form1

    ' Display the weird string described in the lesson.
    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        ' Get the user's input.
        Dim number As Integer = txtNumber.Text

        ' Create the string and display it.
        txtResult.Text = StringOfNumbers(number)
    End Sub
End Class
