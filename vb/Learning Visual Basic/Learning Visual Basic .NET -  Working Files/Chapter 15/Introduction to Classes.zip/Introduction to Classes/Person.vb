﻿Public Class Person
    Public FirstName, LastName As String
    Public MailingAddress As Address
End Class
