﻿Public Class NewCustomerForm

End Class