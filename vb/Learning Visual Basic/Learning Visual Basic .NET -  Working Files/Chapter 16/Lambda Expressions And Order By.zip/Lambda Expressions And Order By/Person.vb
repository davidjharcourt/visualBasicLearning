﻿Public Class Person
    Public FirstName, LastName As String
    Public Age As Integer
End Class
