﻿Public Class Form1

    Private Sub btnSetValues_Click(sender As Object, e As EventArgs) Handles btnSetValues.Click
        Dim dialog As AddressDialog
        dialog = New AddressDialog()

        dialog.txtFirstName.Text = txtFirstName.Text
        dialog.txtLastName.Text = txtLastName.Text
        dialog.txtStreet.Text = txtStreet.Text
        dialog.txtCity.Text = txtCity.Text
        dialog.txtState.Text = txtState.Text
        dialog.txtZip.Text = txtZip.Text

        If dialog.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtFirstName.Text = dialog.txtFirstName.Text
            txtLastName.Text = dialog.txtLastName.Text
            txtStreet.Text = dialog.txtStreet.Text
            txtCity.Text = dialog.txtCity.Text
            txtState.Text = dialog.txtState.Text
            txtZip.Text = dialog.txtZip.Text
        End If
    End Sub
End Class
