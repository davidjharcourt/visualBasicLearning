﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.lblGreeting = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtBirthday = New System.Windows.Forms.TextBox()
        Me.lblDaysUntilBirthdate = New System.Windows.Forms.Label()
        Me.lblDaysUntilHalloween = New System.Windows.Forms.Label()
        Me.tmrTick = New System.Windows.Forms.Timer(Me.components)
        Me.SuspendLayout()
        '
        'lblGreeting
        '
        Me.lblGreeting.AutoSize = True
        Me.lblGreeting.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblGreeting.Location = New System.Drawing.Point(12, 9)
        Me.lblGreeting.Name = "lblGreeting"
        Me.lblGreeting.Size = New System.Drawing.Size(47, 13)
        Me.lblGreeting.TabIndex = 0
        Me.lblGreeting.Text = "Greeting"
        '
        'Label1
        '
        Me.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Label1.Location = New System.Drawing.Point(115, 60)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Birthday:"
        '
        'txtBirthday
        '
        Me.txtBirthday.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtBirthday.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.txtBirthday.Location = New System.Drawing.Point(169, 57)
        Me.txtBirthday.Name = "txtBirthday"
        Me.txtBirthday.Size = New System.Drawing.Size(100, 20)
        Me.txtBirthday.TabIndex = 2
        '
        'lblDaysUntilBirthdate
        '
        Me.lblDaysUntilBirthdate.AutoSize = True
        Me.lblDaysUntilBirthdate.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblDaysUntilBirthdate.Location = New System.Drawing.Point(12, 101)
        Me.lblDaysUntilBirthdate.Name = "lblDaysUntilBirthdate"
        Me.lblDaysUntilBirthdate.Size = New System.Drawing.Size(0, 13)
        Me.lblDaysUntilBirthdate.TabIndex = 4
        '
        'lblDaysUntilHalloween
        '
        Me.lblDaysUntilHalloween.AutoSize = True
        Me.lblDaysUntilHalloween.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.lblDaysUntilHalloween.Location = New System.Drawing.Point(12, 33)
        Me.lblDaysUntilHalloween.Name = "lblDaysUntilHalloween"
        Me.lblDaysUntilHalloween.Size = New System.Drawing.Size(108, 13)
        Me.lblDaysUntilHalloween.TabIndex = 5
        Me.lblDaysUntilHalloween.Text = "Days Until Halloween"
        '
        'tmrTick
        '
        Me.tmrTick.Enabled = True
        Me.tmrTick.Interval = 1000
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(384, 134)
        Me.Controls.Add(Me.lblDaysUntilHalloween)
        Me.Controls.Add(Me.lblDaysUntilBirthdate)
        Me.Controls.Add(Me.txtBirthday)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblGreeting)
        Me.Name = "Form1"
        Me.Text = "Dates, Times, and TimeSpans"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblGreeting As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtBirthday As System.Windows.Forms.TextBox
    Friend WithEvents lblDaysUntilBirthdate As System.Windows.Forms.Label
    Friend WithEvents lblDaysUntilHalloween As System.Windows.Forms.Label
    Friend WithEvents tmrTick As System.Windows.Forms.Timer

End Class
