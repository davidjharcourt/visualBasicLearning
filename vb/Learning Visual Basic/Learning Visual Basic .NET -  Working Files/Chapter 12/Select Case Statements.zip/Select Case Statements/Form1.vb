﻿Public Class Form1
    ' Display the user's letter grade.
    Private Sub btnGetGrade_Click(sender As Object, e As EventArgs) Handles btnGetGrade.Click
        ' Get the numeric grade.
        Dim grade As Integer = txtScore.Text

        ' Display the letter grade.
        Select Case grade
            Case Is > 100
                MessageBox.Show("Congratulations! You get an A+!")
            Case 90 To 100
                MessageBox.Show("Awesome! You get an A!")
            Case 80 To 89
                MessageBox.Show("Not bad. You get a B.")
            Case 70 To 79
                MessageBox.Show("You get a C. You can do better!")
            Case 60 To 69
                MessageBox.Show("You get a D. Better watch it!")
            Case 0 To 59
                MessageBox.Show("Sorry, you get an F. You should take the test again.")
            Case Else
                MessageBox.Show("You can't have a score less than 0.")
        End Select
    End Sub
End Class
