﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim annabelle As New Person() With
            {
                .FirstName = "Annabelle",
                .LastName = "Artichoke"
            }
        Dim billy As New Employee() With
            {
                .FirstName = "William",
                .LastName = "Bently",
                .EmployeeId = 12345
            }
        Dim cynthia As New Student() With
            {
                .FirstName = "Cindy",
                .LastName = "Carotine",
                .Year = StudentYears.Junior
            }
        Dim darnelle As New Manager() With
            {
                .FirstName = "Darnelle",
                .LastName = "Darstairs",
                .EmployeeId = "67890",
                .Department = "Research"
            }

        ' Make a list holding everyone.
        Dim people As New List(Of Person)()
        people.Add(annabelle)
        people.Add(billy)
        people.Add(cynthia)
        people.Add(darnelle)

        ' Display all their names.
        For Each a_person As Person In people
            a_person.SayYourName()
        Next a_person
    End Sub
End Class
