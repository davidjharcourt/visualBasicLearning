﻿Public Class Form1

    Private Sub mnuFileExit_Click(sender As Object, e As EventArgs) Handles mnuFileExit.Click
        Me.Close()
    End Sub

    Private Sub mnuSettingsForegroundColor_Click(sender As Object, e As EventArgs) Handles mnuSettingsForegroundColor.Click
        cdColor.Color = Me.ForeColor
        If cdColor.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Me.ForeColor = cdColor.Color
        End If
    End Sub

    Private Sub mnuSettingsBackgroundColor_Click(sender As Object, e As EventArgs) Handles mnuSettingsBackgroundColor.Click
        cdColor.Color = Me.BackColor
        If cdColor.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Me.BackColor = cdColor.Color
        End If
    End Sub

    Private Sub mnuSettingsFont_Click(sender As Object, e As EventArgs) Handles mnuSettingsFont.Click
        fdFont.Font = Me.Font
        If fdFont.ShowDialog() = Windows.Forms.DialogResult.OK Then
            Me.Font = fdFont.Font
        End If
    End Sub
End Class
