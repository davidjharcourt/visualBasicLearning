﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtValue1 = New System.Windows.Forms.TextBox()
        Me.txtValue2 = New System.Windows.Forms.TextBox()
        Me.txtValue4 = New System.Windows.Forms.TextBox()
        Me.txtValue3 = New System.Windows.Forms.TextBox()
        Me.txtValue5 = New System.Windows.Forms.TextBox()
        Me.btnCalculateAverage = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(39, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Values"
        '
        'txtValue1
        '
        Me.txtValue1.Location = New System.Drawing.Point(15, 25)
        Me.txtValue1.Name = "txtValue1"
        Me.txtValue1.Size = New System.Drawing.Size(46, 20)
        Me.txtValue1.TabIndex = 1
        Me.txtValue1.Text = "10"
        Me.txtValue1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtValue2
        '
        Me.txtValue2.Location = New System.Drawing.Point(67, 25)
        Me.txtValue2.Name = "txtValue2"
        Me.txtValue2.Size = New System.Drawing.Size(46, 20)
        Me.txtValue2.TabIndex = 2
        Me.txtValue2.Text = "10"
        Me.txtValue2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtValue4
        '
        Me.txtValue4.Location = New System.Drawing.Point(171, 25)
        Me.txtValue4.Name = "txtValue4"
        Me.txtValue4.Size = New System.Drawing.Size(46, 20)
        Me.txtValue4.TabIndex = 4
        Me.txtValue4.Text = "10"
        Me.txtValue4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtValue3
        '
        Me.txtValue3.Location = New System.Drawing.Point(119, 25)
        Me.txtValue3.Name = "txtValue3"
        Me.txtValue3.Size = New System.Drawing.Size(46, 20)
        Me.txtValue3.TabIndex = 3
        Me.txtValue3.Text = "10"
        Me.txtValue3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtValue5
        '
        Me.txtValue5.Location = New System.Drawing.Point(223, 25)
        Me.txtValue5.Name = "txtValue5"
        Me.txtValue5.Size = New System.Drawing.Size(46, 20)
        Me.txtValue5.TabIndex = 5
        Me.txtValue5.Text = "10"
        Me.txtValue5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnCalculateAverage
        '
        Me.btnCalculateAverage.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.btnCalculateAverage.Location = New System.Drawing.Point(84, 73)
        Me.btnCalculateAverage.Name = "btnCalculateAverage"
        Me.btnCalculateAverage.Size = New System.Drawing.Size(116, 23)
        Me.btnCalculateAverage.TabIndex = 6
        Me.btnCalculateAverage.Text = "Calculate Average"
        Me.btnCalculateAverage.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(69, 115)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(40, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Result:"
        '
        'txtResult
        '
        Me.txtResult.Anchor = System.Windows.Forms.AnchorStyles.Top
        Me.txtResult.Location = New System.Drawing.Point(115, 112)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.ReadOnly = True
        Me.txtResult.Size = New System.Drawing.Size(100, 20)
        Me.txtResult.TabIndex = 8
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalculateAverage
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 146)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.btnCalculateAverage)
        Me.Controls.Add(Me.txtValue5)
        Me.Controls.Add(Me.txtValue4)
        Me.Controls.Add(Me.txtValue3)
        Me.Controls.Add(Me.txtValue2)
        Me.Controls.Add(Me.txtValue1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Using Watch Windows"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtValue1 As System.Windows.Forms.TextBox
    Friend WithEvents txtValue2 As System.Windows.Forms.TextBox
    Friend WithEvents txtValue4 As System.Windows.Forms.TextBox
    Friend WithEvents txtValue3 As System.Windows.Forms.TextBox
    Friend WithEvents txtValue5 As System.Windows.Forms.TextBox
    Friend WithEvents btnCalculateAverage As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtResult As System.Windows.Forms.TextBox

End Class
