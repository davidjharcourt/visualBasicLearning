﻿Public Class Form1
    ' Display some people.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim person1 As New Person() With
            {
                .FirstName = "George",
                .LastName = "Washington"
            }
        Dim person2 As Person = New Employee() With
            {
                .FirstName = "John",
                .LastName = "Adams",
                .EmployeeId = 2
            }

        lstPeople.Items.Add(person1.Name())
        lstPeople.Items.Add(person2.Name())
    End Sub
End Class
