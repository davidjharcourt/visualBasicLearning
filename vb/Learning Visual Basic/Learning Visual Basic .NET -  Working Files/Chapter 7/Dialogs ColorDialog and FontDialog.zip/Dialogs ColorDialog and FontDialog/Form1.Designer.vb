﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.SettingsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuFileExit = New System.Windows.Forms.ToolStripMenuItem()
        Me.SettingsToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSettingsForegroundColor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSettingsBackgroundColor = New System.Windows.Forms.ToolStripMenuItem()
        Me.mnuSettingsFont = New System.Windows.Forms.ToolStripMenuItem()
        Me.cdColor = New System.Windows.Forms.ColorDialog()
        Me.fdFont = New System.Windows.Forms.FontDialog()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.SettingsToolStripMenuItem, Me.SettingsToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(417, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'SettingsToolStripMenuItem
        '
        Me.SettingsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuFileExit})
        Me.SettingsToolStripMenuItem.Name = "SettingsToolStripMenuItem"
        Me.SettingsToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.SettingsToolStripMenuItem.Text = "&File"
        '
        'mnuFileExit
        '
        Me.mnuFileExit.Name = "mnuFileExit"
        Me.mnuFileExit.Size = New System.Drawing.Size(92, 22)
        Me.mnuFileExit.Text = "E&xit"
        '
        'SettingsToolStripMenuItem1
        '
        Me.SettingsToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.mnuSettingsForegroundColor, Me.mnuSettingsBackgroundColor, Me.mnuSettingsFont})
        Me.SettingsToolStripMenuItem1.Name = "SettingsToolStripMenuItem1"
        Me.SettingsToolStripMenuItem1.Size = New System.Drawing.Size(61, 20)
        Me.SettingsToolStripMenuItem1.Text = "&Settings"
        '
        'mnuSettingsForegroundColor
        '
        Me.mnuSettingsForegroundColor.Name = "mnuSettingsForegroundColor"
        Me.mnuSettingsForegroundColor.Size = New System.Drawing.Size(170, 22)
        Me.mnuSettingsForegroundColor.Text = "&Foreground Color"
        '
        'mnuSettingsBackgroundColor
        '
        Me.mnuSettingsBackgroundColor.Name = "mnuSettingsBackgroundColor"
        Me.mnuSettingsBackgroundColor.Size = New System.Drawing.Size(170, 22)
        Me.mnuSettingsBackgroundColor.Text = "&Background Color"
        '
        'mnuSettingsFont
        '
        Me.mnuSettingsFont.Name = "mnuSettingsFont"
        Me.mnuSettingsFont.Size = New System.Drawing.Size(170, 22)
        Me.mnuSettingsFont.Text = "F&ont"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 34)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(91, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "This is a test label"
        '
        'Form1
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.ClientSize = New System.Drawing.Size(417, 261)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "Dialogs: ColorDialog and FontDialog"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents SettingsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuFileExit As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SettingsToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSettingsBackgroundColor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSettingsFont As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents mnuSettingsForegroundColor As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents cdColor As System.Windows.Forms.ColorDialog
    Friend WithEvents fdFont As System.Windows.Forms.FontDialog
    Friend WithEvents Label1 As System.Windows.Forms.Label

End Class
