﻿Public Class Form1

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        lstNumbers.Items.Clear()

        Dim value As Integer = txtValue.Text
        Do Until value = 0
            lstNumbers.Items.Add(value)
            value \= 2
        Loop

        txtValue.Clear()
        txtValue.Focus()
    End Sub
End Class
