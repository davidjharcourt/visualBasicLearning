﻿Public Class Form1

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        ' Get the user's inputs.
        Dim number As Integer = txtNumber.Text
        Dim text As String = txtString.Text

        ' Create an empty array of strings.
        Dim strings(-1) As String

        ' First using a subroutine.
        MakeStrings(number, text, strings)
        ' Display the result.
        lstStrings1.Items.Clear()
        For i As Integer = 0 To number - 1
            lstStrings1.Items.Add(strings(i))
        Next i

        ' Next using a function.
        strings = MakeStringsFunction(number, text)
        ' Display the result.
        lstStrings2.Items.Clear()
        For i As Integer = 0 To number - 1
            lstStrings2.Items.Add(strings(i))
        Next i
    End Sub
End Class
