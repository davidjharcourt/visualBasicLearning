﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.pdocReport = New System.Drawing.Printing.PrintDocument()
        Me.ppdReport = New System.Windows.Forms.PrintPreviewDialog()
        Me.SuspendLayout()
        '
        'btnPrint
        '
        Me.btnPrint.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnPrint.Location = New System.Drawing.Point(105, 44)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(75, 23)
        Me.btnPrint.TabIndex = 0
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'pdocReport
        '
        '
        'ppdReport
        '
        Me.ppdReport.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.ppdReport.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.ppdReport.ClientSize = New System.Drawing.Size(400, 300)
        Me.ppdReport.Document = Me.pdocReport
        Me.ppdReport.Enabled = True
        Me.ppdReport.Icon = CType(resources.GetObject("ppdReport.Icon"), System.Drawing.Icon)
        Me.ppdReport.Name = "ppdReport"
        Me.ppdReport.Visible = False
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 111)
        Me.Controls.Add(Me.btnPrint)
        Me.Name = "Form1"
        Me.Text = "Printing A Report"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents pdocReport As System.Drawing.Printing.PrintDocument
    Friend WithEvents ppdReport As System.Windows.Forms.PrintPreviewDialog

End Class
