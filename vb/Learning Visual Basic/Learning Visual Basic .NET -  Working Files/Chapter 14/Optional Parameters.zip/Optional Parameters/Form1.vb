﻿Public Class Form1

    Private Sub btnPlaceOrder_Click(sender As Object, e As EventArgs) Handles btnPlaceOrder.Click
        ' Get the item.
        Dim item As String = txtItem.Text

        ' See if the date is blank.
        If txtDate.Text = "" Then
            ' The date is blank. Leave it out.
            PlaceOrder(item)
        Else
            ' The date is present. Use it.
            Dim delivery_date As Date = txtDate.Text
            PlaceOrder(item, delivery_date)
        End If

    End Sub
End Class
