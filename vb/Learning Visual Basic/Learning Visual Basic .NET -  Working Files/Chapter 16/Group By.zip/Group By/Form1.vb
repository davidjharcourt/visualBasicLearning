﻿Public Class Form1
    ' List people, their ages, and their prices sorted by age.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim people As New List(Of Person)()
        people.Add(New Person() With {.FirstName = "Valerie", .LastName = "Ramirez", .Age = 12})
        people.Add(New Person() With {.FirstName = "Ian", .LastName = "Moreno", .Age = 17})
        people.Add(New Person() With {.FirstName = "Lorraine", .LastName = "Huff", .Age = 21})
        people.Add(New Person() With {.FirstName = "Elmer", .LastName = "Rice", .Age = 4})
        people.Add(New Person() With {.FirstName = "Julio", .LastName = "Ball", .Age = 3})
        people.Add(New Person() With {.FirstName = "Sharon", .LastName = "Rodgers", .Age = 7})
        people.Add(New Person() With {.FirstName = "Vicki", .LastName = "Torres", .Age = 15})
        people.Add(New Person() With {.FirstName = "Eileen", .LastName = "Cooper", .Age = 16})
        people.Add(New Person() With {.FirstName = "Miguel", .LastName = "Frazier", .Age = 9})
        people.Add(New Person() With {.FirstName = "Jackie", .LastName = "Hardy", .Age = 20})
        people.Add(New Person() With {.FirstName = "Gretchen", .LastName = "Olson", .Age = 11})
        people.Add(New Person() With {.FirstName = "Lila", .LastName = "Bennett", .Age = 61})

        ' Lambda expression to convert age into age category.
        Dim admission_type = Function(age As Integer) As String
                                 If age <= 5 Then Return "Child"
                                 If age <= 17 Then Return "Youth"
                                 If age <= 59 Then Return "Adult"
                                 Return "Senior"
                             End Function

        ' Lambda expression to convert age category into admission price.
        Dim admission_price = Function(age_category As String) As Decimal
                                  If age_category = "Child" Then Return 5
                                  If age_category = "Youth" Then Return 7.5
                                  If age_category = "Adult" Then Return 12.5
                                  Return 5
                              End Function

        ' Group by age category.
        Dim group_by_age =
            From per As Person In people
            Group per By Key = admission_type(per.Age) Into Group
            Select PeopleInGroup = Group,
                   AgeType = Key
            Order By AgeType

        ' Display the results.
        For Each age_group In group_by_age
            Dim group_title As String = age_group.AgeType & " (" &
                admission_price(age_group.AgeType).ToString("C") & ")"
            Dim node As TreeNode = trvPeople.Nodes.Add(group_title)
            For Each per As Person In age_group.PeopleInGroup
                node.Nodes.Add(per.FirstName & " " & per.LastName)
            Next per
        Next age_group

        trvPeople.ExpandAll()
    End Sub
End Class
