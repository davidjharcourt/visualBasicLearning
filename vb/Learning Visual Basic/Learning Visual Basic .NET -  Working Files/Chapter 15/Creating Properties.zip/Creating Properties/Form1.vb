﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Make some Persons.
        Dim ann As New Person()
        ann.FirstName = "Ann"
        ann.LastName = "Archer"
        ann.Street = "1313 Mockingbird Ln"
        ann.City = "Mockingbird Heights"
        ann.Street = "CA"
        ann.Zip = "92001"

        Dim bob As New Person() With
        {
            .FirstName = "Bob",
            .LastName = "Baker",
            .Street = "1337 Leet St",
            .City = "Bugsville",
            .State = "HI",
            .Zip = "98765"
        }
    End Sub
End Class
