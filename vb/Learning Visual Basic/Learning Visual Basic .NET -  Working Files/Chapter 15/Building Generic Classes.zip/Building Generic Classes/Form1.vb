﻿Public Class Form1
    ' The queue.
    Private Queue As New PriorityQueue(Of String, Integer)()

    ' Add an item to the queue.
    Private Sub btnEnqueue_Click(sender As Object, e As EventArgs) Handles btnEnqueue.Click
        Queue.Enqueue(txtItem.Text, txtQuantity.Text, txtPriority.Text)

        txtItem.Clear()
        txtItem.Focus()
        txtQuantity.Clear()
        txtPriority.Clear()
    End Sub

    ' Get the highest priority item from the queue.
    Private Sub btnDequeue_Click(sender As Object, e As EventArgs) Handles btnDequeue.Click
        Dim item As String = ""
        Dim quantity As Integer = 0
        Queue.Dequeue(item, quantity)

        txtItem.Text = item
        txtQuantity.Text = quantity

        txtItem.Focus()
        txtPriority.Clear()
    End Sub
End Class
