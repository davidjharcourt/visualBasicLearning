﻿Public Class Form1

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        ' Tip percentages.
        Const tip_percent_10 As Decimal = 0.1
        Const tip_percent_15 As Decimal = 0.15
        Const tip_percent_20 As Decimal = 0.2
        Const tip_percent_25 As Decimal = 0.25

        ' Get the user's input.
        Dim amount As Decimal
        amount = txtAmount.Text

        ' Calculate results.
        Dim tip10, total10, tip15, total15, tip20, total20, tip25, total25 As Decimal
        tip10 = amount * tip_percent_10
        tip15 = amount * tip_percent_15
        tip20 = amount * tip_percent_20
        tip25 = amount * tip_percent_25

        total10 = amount + tip10
        total15 = amount + tip15
        total20 = amount + tip20
        total25 = amount + tip25

        ' Display the results.
        txt10PctTip.Text = tip10.ToString("C")
        txt15PctTip.Text = tip15.ToString("C")
        txt20PctTip.Text = tip20.ToString("C")
        txt25PctTip.Text = tip25.ToString("C")

        txt10PctTotal.Text = total10.ToString("C")
        txt15PctTotal.Text = total15.ToString("C")
        txt20PctTotal.Text = total20.ToString("C")
        txt25PctTotal.Text = total25.ToString("C")
    End Sub
End Class
