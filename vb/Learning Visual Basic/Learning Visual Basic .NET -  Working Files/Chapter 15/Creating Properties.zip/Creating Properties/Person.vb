﻿Public Class Person
    Private _FirstName As String
    Public Property FirstName As String
        Get
            Return _FirstName
        End Get
        Set(value As String)
            If value.Length = 0 Then
                Throw New ArgumentOutOfRangeException("FirstName", "FirstName cannot be blank")
            End If
            _FirstName = value
        End Set
    End Property

    Private _LastName As String
    Public Property LastName As String
        Get
            Return _LastName
        End Get
        Set(value As String)
            If value.Length = 0 Then
                Throw New ArgumentOutOfRangeException("LastName", "LastName cannot be blank")
            End If
            _LastName = value
        End Set
    End Property

    Private _Street As String
    Public Property Street As String
        Get
            Return _Street
        End Get
        Set(value As String)
            If value.Length = 0 Then
                Throw New ArgumentOutOfRangeException("Street", "Street cannot be blank")
            End If
            _Street = value
        End Set
    End Property

    Private _City As String
    Public Property City As String
        Get
            Return _City
        End Get
        Set(value As String)
            If value.Length = 0 Then
                Throw New ArgumentOutOfRangeException("City", "City cannot be blank")
            End If
            _City = value
        End Set
    End Property

    Private _State As String
    Public Property State As String
        Get
            Return _State
        End Get
        Set(value As String)
            If value.Length = 0 Then
                Throw New ArgumentOutOfRangeException("State", "State cannot be blank")
            End If
            _State = value
        End Set
    End Property

    Private _Zip As String
    Public Property Zip As String
        Get
            Return _Zip
        End Get
        Set(value As String)
            Dim numeric_value As Integer = value
            If (numeric_value < 0) Or (numeric_value > 99999) Then
                Throw New ArgumentOutOfRangeException("Zip", "Zip must be between 0 and 99999")
            End If
            _Zip = value
        End Set
    End Property
End Class
