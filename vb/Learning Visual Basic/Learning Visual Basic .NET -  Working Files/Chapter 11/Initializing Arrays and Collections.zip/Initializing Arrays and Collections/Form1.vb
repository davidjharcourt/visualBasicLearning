﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' An array holding lists of strings.
        Dim string_lists() As List(Of String) =
            {
                New List(Of String)() From {"ash", "beech", "cedar"},
                New List(Of String)() From {"aster", "bromeliad", "clover", "danddelion"}
            }

        ' A dictionary holding String/List(Of String) pairs.
        Dim meal_choices As New Dictionary(Of String, List(Of String)) From
            {
                {"entrée", New List(Of String)() From {"sandwich", "soup", "pasta"}},
                {"drink", New List(Of String)() From {"water", "soda", "milk"}},
                {"dessert", New List(Of String)() From {"cookie", "ice cream", "brownie", "pie"}}
            }

        Stop
    End Sub
End Class
