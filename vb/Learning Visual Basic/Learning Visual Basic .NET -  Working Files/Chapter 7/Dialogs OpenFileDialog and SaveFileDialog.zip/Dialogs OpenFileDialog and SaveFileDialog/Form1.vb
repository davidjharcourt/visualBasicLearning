﻿Public Class Form1
    ' Comment: If the user enters a file name without an extension,
    ' the dialog adds the extension used by the selected filter by default.

    Private Sub mnuFileOpen_Click(sender As Object, e As EventArgs) Handles mnuFileOpen.Click
        If ofdFile.ShowDialog() = Windows.Forms.DialogResult.OK Then
            MessageBox.Show(ofdFile.FileName)
        End If
    End Sub

    Private Sub mnuFileSave_Click(sender As Object, e As EventArgs) Handles mnuFileSave.Click
        If sfdFile.ShowDialog() = Windows.Forms.DialogResult.OK Then
            MessageBox.Show(sfdFile.FileName)
        End If
    End Sub
End Class
