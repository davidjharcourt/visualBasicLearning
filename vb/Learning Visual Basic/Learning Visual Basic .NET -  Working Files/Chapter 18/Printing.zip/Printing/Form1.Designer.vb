﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtNumPages = New System.Windows.Forms.TextBox()
        Me.btnPrint = New System.Windows.Forms.Button()
        Me.pdocManyPages = New System.Drawing.Printing.PrintDocument()
        Me.ppdManyPages = New System.Windows.Forms.PrintPreviewDialog()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(50, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "# Pages:"
        '
        'txtNumPages
        '
        Me.txtNumPages.Location = New System.Drawing.Point(68, 14)
        Me.txtNumPages.Name = "txtNumPages"
        Me.txtNumPages.Size = New System.Drawing.Size(58, 20)
        Me.txtNumPages.TabIndex = 1
        Me.txtNumPages.Text = "10"
        Me.txtNumPages.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnPrint
        '
        Me.btnPrint.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnPrint.Location = New System.Drawing.Point(152, 12)
        Me.btnPrint.Name = "btnPrint"
        Me.btnPrint.Size = New System.Drawing.Size(75, 23)
        Me.btnPrint.TabIndex = 2
        Me.btnPrint.Text = "Print"
        Me.btnPrint.UseVisualStyleBackColor = True
        '
        'pdocManyPages
        '
        '
        'ppdManyPages
        '
        Me.ppdManyPages.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.ppdManyPages.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.ppdManyPages.ClientSize = New System.Drawing.Size(400, 300)
        Me.ppdManyPages.Document = Me.pdocManyPages
        Me.ppdManyPages.Enabled = True
        Me.ppdManyPages.Icon = CType(resources.GetObject("ppdManyPages.Icon"), System.Drawing.Icon)
        Me.ppdManyPages.Name = "ppdManyPages"
        Me.ppdManyPages.Visible = False
        '
        'Form1
        '
        Me.AcceptButton = Me.btnPrint
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(239, 56)
        Me.Controls.Add(Me.btnPrint)
        Me.Controls.Add(Me.txtNumPages)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Printing"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtNumPages As System.Windows.Forms.TextBox
    Friend WithEvents btnPrint As System.Windows.Forms.Button
    Friend WithEvents pdocManyPages As System.Drawing.Printing.PrintDocument
    Friend WithEvents ppdManyPages As System.Windows.Forms.PrintPreviewDialog

End Class
