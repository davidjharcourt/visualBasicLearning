﻿Public Class Form1
    ' The account.
    Private WithEvents Account As OverdraftAccount

    ' Create the OverdraftAccount.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Account = New OverdraftAccount()
        Account.Balance = 100

        txtBalance.Text = Account.Balance.ToString("C")
    End Sub

    ' Add money to the account.
    Private Sub btnCredit_Click(sender As Object, e As EventArgs) Handles btnCredit.Click
        Account.Credit(txtAmount.Text)

        txtAmount.Clear()
        txtAmount.Focus()
        txtBalance.Text = Account.Balance.ToString("C")
    End Sub

    ' Remove money from the account.
    Private Sub btnDebit_Click(sender As Object, e As EventArgs) Handles btnDebit.Click
        Account.Debit(txtAmount.Text)

        txtAmount.Clear()
        txtAmount.Focus()
        txtBalance.Text = Account.Balance.ToString("C")
    End Sub

    ' An overdraft occurred.
    Private Sub Account_Overdraft() Handles Account.Overdraft
        MessageBox.Show("Used overdraft")
    End Sub

    ' The account is overdrawn.
    Private Sub Account_Overdrawn() Handles Account.Overdrawn
        MessageBox.Show("Insufficient funds")
    End Sub
End Class
