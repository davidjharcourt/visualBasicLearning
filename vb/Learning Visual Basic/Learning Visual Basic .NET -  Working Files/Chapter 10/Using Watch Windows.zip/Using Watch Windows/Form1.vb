﻿Public Class Form1

    Private Sub btnCalculateAverage_Click(sender As Object, e As EventArgs) Handles btnCalculateAverage.Click
        ' Get the user's inputs.
        Dim value1 As Integer = txtValue1.Text
        Dim value2 As Integer = txtValue2.Text
        Dim value3 As Integer = txtValue3.Text
        Dim value4 As Integer = txtValue4.Text
        Dim value5 As Integer = txtValue5.Text

        ' Calculate results.
        Dim total As Integer
        total = value1
        total += value2
        total += value3
        total += value4
        total += value4
        total += value5
        Dim average As Single = total / 5

        ' Display results.
        txtResult.Text = average
    End Sub
End Class
