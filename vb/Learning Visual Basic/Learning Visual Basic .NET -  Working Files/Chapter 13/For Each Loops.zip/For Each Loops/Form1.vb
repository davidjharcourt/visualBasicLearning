﻿Public Class Form1
    ' The list of values.
    Private Values As New List(Of String)()

    ' Add a value to the list.
    Private Sub btnAddValue_Click(sender As Object, e As EventArgs) Handles btnAddValue.Click
        ' Add the value to the list.
        Values.Add(txtValue.Text)

        ' Clear the value TextBox.
        txtValue.Clear()
        txtValue.Focus()

        ' Make a string showing the list's contents.
        Dim contents As String = ""
        For Each value As String In Values
            contents &= value & ", "
        Next value

        ' Remove the final comma and space.
        contents = contents.Substring(0, contents.Length - 2)

        ' Display the result.
        txtResult.Text = contents
    End Sub
End Class
