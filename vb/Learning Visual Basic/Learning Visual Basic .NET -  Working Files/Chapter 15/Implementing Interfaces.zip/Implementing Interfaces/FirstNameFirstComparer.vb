﻿Public Class FirstNameFirstComparer
    Implements IComparer(Of Person)

    Public Function Compare(x As Person, y As Person) As Integer Implements IComparer(Of Person).Compare
        Return x.ToString().CompareTo(y.ToString())
    End Function
End Class
