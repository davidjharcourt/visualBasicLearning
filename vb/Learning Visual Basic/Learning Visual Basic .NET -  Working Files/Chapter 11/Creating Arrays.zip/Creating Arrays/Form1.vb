﻿Public Class Form1
    ' The array of strings.
    Private Values(0 To -1) As String

    ' Add a string to the array.
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ' Get the old upper bound.
        Dim old_upper_bound As Integer = Values.Length - 1

        ' Make room for the new item.
        ReDim Preserve Values(0 To old_upper_bound + 1)

        ' Insert the new item.
        Values(old_upper_bound + 1) = txtString.Text

        ' Clear the TextBox.
        txtString.Clear()
        txtString.Focus()
    End Sub

    ' Remove a string from the array.
    Private Sub btnRemove_Click(sender As Object, e As EventArgs) Handles btnRemove.Click
        ' Get the old upper bound.
        Dim old_upper_bound As Integer = Values.Length - 1

        ' Make sure the array isn't empty.
        If old_upper_bound < 0 Then
            ' There are no more items. Say so.
            txtString.Text = "<No more items>"
        Else
            ' Display the last item in the array.
            txtString.Text = Values(old_upper_bound)

            ' Resize the array to remove the last item.
            ReDim Preserve Values(0 To old_upper_bound - 1)
        End If
    End Sub
End Class
