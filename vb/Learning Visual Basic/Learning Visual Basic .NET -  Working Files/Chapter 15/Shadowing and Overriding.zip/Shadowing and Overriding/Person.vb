﻿Public Class Person
    Public FirstName, LastName As String

    Public Overridable Function Name() As String
        Return FirstName & " " & LastName
    End Function
End Class

Public Class Employee
    Inherits Person

    Public EmployeeId As Integer

    Public Overrides Function Name() As String
        Return MyBase.Name() & " (" & EmployeeId & ")"
    End Function
End Class
