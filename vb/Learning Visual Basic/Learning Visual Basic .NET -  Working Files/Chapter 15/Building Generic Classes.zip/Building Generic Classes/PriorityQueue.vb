﻿Public Class PriorityQueue(Of T1, T2)
    ' A data type to hold items in the queue.
    Private Class DataItem
        Public Priority As Integer
        Public Data1 As T1
        Public Data2 As T2
    End Class

    ' A list of items in the queue.
    Private Items As List(Of DataItem) = New List(Of DataItem)()

    ' Add an item to the priority queue.
    Public Sub Enqueue(new_data1 As T1, new_data2 As T2, new_priority As Integer)
        Dim new_item As New DataItem() With
            {
                .Data1 = new_data1,
                .Data2 = new_data2,
                .Priority = new_priority
            }

        Items.Add(new_item)
    End Sub

    ' Remove the item with the highest priority.
    Public Sub Dequeue(ByRef data_value1 As T1, ByRef data_value2 As T2)
        ' Find the highest priority item.
        Dim best_item As DataItem = Nothing
        Dim best_priority As Integer = Integer.MinValue
        For i As Integer = 0 To Items.Count - 1
            If Items(i).Priority > best_priority Then
                best_item = Items(i)
                best_priority = Items(i).Priority
            End If
        Next i

        ' Remove the item from the list.
        Items.Remove(best_item)

        ' Return the item's data.
        data_value1 = best_item.Data1
        data_value2 = best_item.Data2
    End Sub
End Class
