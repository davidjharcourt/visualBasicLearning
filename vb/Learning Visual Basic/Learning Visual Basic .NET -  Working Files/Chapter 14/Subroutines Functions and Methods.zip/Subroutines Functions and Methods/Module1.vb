﻿Module Module1
    ' Return the weird string described in the lesson.
    Public Function StringOfNumbers(number As Integer) As String
        ' Make a string to hold the result.
        Dim result As String = ""

        ' Loop through each value smaller than the number.
        For i As Integer = 1 To number
            ' Make the required number of this value.
            Dim line As String = ""
            For j As Integer = 1 To i
                line &= i & " "
            Next j

            ' Add the new line to the result.
            result &= line & vbCrLf
        Next i

        ' Return the result.
        Return result
    End Function
End Module
