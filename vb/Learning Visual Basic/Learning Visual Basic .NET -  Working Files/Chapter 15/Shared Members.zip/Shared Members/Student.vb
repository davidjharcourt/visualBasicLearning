﻿Public Class Student
    Public FirstName, LastName As String

    Public Shared NumberOfStudents As Integer = 0

    ' A private constructor.
    ' Because the class includes a constructor, there is no
    ' default constructor so the main program must use this one.
    ' But this one is declared Private so the main program cannot use it.
    ' This means the main program must use the MakeStudent factory
    ' method to create new Student objects.
    Private Sub New()

    End Sub

    ' Factory method.
    Public Shared Function MakeStudent(first_name As String, last_name As String) As Student
        ' Increment the number of students.
        NumberOfStudents += 1

        ' Look up the student in the database.
        '...

        ' Return the new student.
        Return New Student() With
            {
                .FirstName = first_name,
                .LastName = last_name
            }
    End Function
End Class
