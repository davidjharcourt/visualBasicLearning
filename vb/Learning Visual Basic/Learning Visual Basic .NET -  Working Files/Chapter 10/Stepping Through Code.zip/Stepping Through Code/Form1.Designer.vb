﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtItem1 = New System.Windows.Forms.TextBox()
        Me.txtPriceEach1 = New System.Windows.Forms.TextBox()
        Me.nudQuantity1 = New System.Windows.Forms.NumericUpDown()
        Me.txtExtended1 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtExtended2 = New System.Windows.Forms.TextBox()
        Me.nudQuantity2 = New System.Windows.Forms.NumericUpDown()
        Me.txtPriceEach2 = New System.Windows.Forms.TextBox()
        Me.txtItem2 = New System.Windows.Forms.TextBox()
        Me.txtExtended4 = New System.Windows.Forms.TextBox()
        Me.nudQuantity4 = New System.Windows.Forms.NumericUpDown()
        Me.txtPriceEach4 = New System.Windows.Forms.TextBox()
        Me.txtItem4 = New System.Windows.Forms.TextBox()
        Me.txtExtended3 = New System.Windows.Forms.TextBox()
        Me.nudQuantity3 = New System.Windows.Forms.NumericUpDown()
        Me.txtPriceEach3 = New System.Windows.Forms.TextBox()
        Me.txtItem3 = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txtSubtotal = New System.Windows.Forms.TextBox()
        Me.txtTax = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        CType(Me.nudQuantity1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudQuantity2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudQuantity4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.nudQuantity3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Item"
        '
        'Label2
        '
        Me.Label2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(245, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(59, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Price Each"
        '
        'Label3
        '
        Me.Label3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(193, 9)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(46, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Quantity"
        '
        'txtItem1
        '
        Me.txtItem1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtItem1.Location = New System.Drawing.Point(15, 25)
        Me.txtItem1.Name = "txtItem1"
        Me.txtItem1.Size = New System.Drawing.Size(165, 20)
        Me.txtItem1.TabIndex = 3
        Me.txtItem1.Text = "Notebook"
        '
        'txtPriceEach1
        '
        Me.txtPriceEach1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPriceEach1.Location = New System.Drawing.Point(245, 25)
        Me.txtPriceEach1.Name = "txtPriceEach1"
        Me.txtPriceEach1.Size = New System.Drawing.Size(72, 20)
        Me.txtPriceEach1.TabIndex = 5
        Me.txtPriceEach1.Text = "$1.19"
        Me.txtPriceEach1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'nudQuantity1
        '
        Me.nudQuantity1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.nudQuantity1.Location = New System.Drawing.Point(186, 26)
        Me.nudQuantity1.Name = "nudQuantity1"
        Me.nudQuantity1.Size = New System.Drawing.Size(53, 20)
        Me.nudQuantity1.TabIndex = 6
        Me.nudQuantity1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudQuantity1.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'txtExtended1
        '
        Me.txtExtended1.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtExtended1.Location = New System.Drawing.Point(323, 25)
        Me.txtExtended1.Name = "txtExtended1"
        Me.txtExtended1.ReadOnly = True
        Me.txtExtended1.Size = New System.Drawing.Size(72, 20)
        Me.txtExtended1.TabIndex = 8
        Me.txtExtended1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label4
        '
        Me.Label4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(330, 9)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(52, 13)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Extended"
        '
        'txtExtended2
        '
        Me.txtExtended2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtExtended2.Location = New System.Drawing.Point(323, 51)
        Me.txtExtended2.Name = "txtExtended2"
        Me.txtExtended2.ReadOnly = True
        Me.txtExtended2.Size = New System.Drawing.Size(72, 20)
        Me.txtExtended2.TabIndex = 12
        Me.txtExtended2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'nudQuantity2
        '
        Me.nudQuantity2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.nudQuantity2.Location = New System.Drawing.Point(186, 52)
        Me.nudQuantity2.Name = "nudQuantity2"
        Me.nudQuantity2.Size = New System.Drawing.Size(53, 20)
        Me.nudQuantity2.TabIndex = 11
        Me.nudQuantity2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudQuantity2.Value = New Decimal(New Integer() {12, 0, 0, 0})
        '
        'txtPriceEach2
        '
        Me.txtPriceEach2.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPriceEach2.Location = New System.Drawing.Point(245, 51)
        Me.txtPriceEach2.Name = "txtPriceEach2"
        Me.txtPriceEach2.Size = New System.Drawing.Size(72, 20)
        Me.txtPriceEach2.TabIndex = 10
        Me.txtPriceEach2.Text = "$0.25"
        Me.txtPriceEach2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtItem2
        '
        Me.txtItem2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtItem2.Location = New System.Drawing.Point(15, 51)
        Me.txtItem2.Name = "txtItem2"
        Me.txtItem2.Size = New System.Drawing.Size(165, 20)
        Me.txtItem2.TabIndex = 9
        Me.txtItem2.Text = "Pencil"
        '
        'txtExtended4
        '
        Me.txtExtended4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtExtended4.Location = New System.Drawing.Point(323, 103)
        Me.txtExtended4.Name = "txtExtended4"
        Me.txtExtended4.ReadOnly = True
        Me.txtExtended4.Size = New System.Drawing.Size(72, 20)
        Me.txtExtended4.TabIndex = 20
        Me.txtExtended4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'nudQuantity4
        '
        Me.nudQuantity4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.nudQuantity4.Location = New System.Drawing.Point(186, 104)
        Me.nudQuantity4.Name = "nudQuantity4"
        Me.nudQuantity4.Size = New System.Drawing.Size(53, 20)
        Me.nudQuantity4.TabIndex = 19
        Me.nudQuantity4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudQuantity4.Value = New Decimal(New Integer() {10, 0, 0, 0})
        '
        'txtPriceEach4
        '
        Me.txtPriceEach4.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPriceEach4.Location = New System.Drawing.Point(245, 103)
        Me.txtPriceEach4.Name = "txtPriceEach4"
        Me.txtPriceEach4.Size = New System.Drawing.Size(72, 20)
        Me.txtPriceEach4.TabIndex = 18
        Me.txtPriceEach4.Text = "$0.50"
        Me.txtPriceEach4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtItem4
        '
        Me.txtItem4.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtItem4.Location = New System.Drawing.Point(15, 103)
        Me.txtItem4.Name = "txtItem4"
        Me.txtItem4.Size = New System.Drawing.Size(165, 20)
        Me.txtItem4.TabIndex = 17
        Me.txtItem4.Text = "Cookies"
        '
        'txtExtended3
        '
        Me.txtExtended3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtExtended3.Location = New System.Drawing.Point(323, 77)
        Me.txtExtended3.Name = "txtExtended3"
        Me.txtExtended3.ReadOnly = True
        Me.txtExtended3.Size = New System.Drawing.Size(72, 20)
        Me.txtExtended3.TabIndex = 16
        Me.txtExtended3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'nudQuantity3
        '
        Me.nudQuantity3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.nudQuantity3.Location = New System.Drawing.Point(186, 78)
        Me.nudQuantity3.Name = "nudQuantity3"
        Me.nudQuantity3.Size = New System.Drawing.Size(53, 20)
        Me.nudQuantity3.TabIndex = 15
        Me.nudQuantity3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.nudQuantity3.Value = New Decimal(New Integer() {1, 0, 0, 0})
        '
        'txtPriceEach3
        '
        Me.txtPriceEach3.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtPriceEach3.Location = New System.Drawing.Point(245, 77)
        Me.txtPriceEach3.Name = "txtPriceEach3"
        Me.txtPriceEach3.Size = New System.Drawing.Size(72, 20)
        Me.txtPriceEach3.TabIndex = 14
        Me.txtPriceEach3.Text = "$495.99"
        Me.txtPriceEach3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtItem3
        '
        Me.txtItem3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtItem3.Location = New System.Drawing.Point(15, 77)
        Me.txtItem3.Name = "txtItem3"
        Me.txtItem3.Size = New System.Drawing.Size(165, 20)
        Me.txtItem3.TabIndex = 13
        Me.txtItem3.Text = "Laptop"
        '
        'Label5
        '
        Me.Label5.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(245, 147)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(49, 13)
        Me.Label5.TabIndex = 21
        Me.Label5.Text = "Subtotal:"
        '
        'txtSubtotal
        '
        Me.txtSubtotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtSubtotal.Location = New System.Drawing.Point(323, 144)
        Me.txtSubtotal.Name = "txtSubtotal"
        Me.txtSubtotal.ReadOnly = True
        Me.txtSubtotal.Size = New System.Drawing.Size(72, 20)
        Me.txtSubtotal.TabIndex = 22
        Me.txtSubtotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txtTax
        '
        Me.txtTax.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTax.Location = New System.Drawing.Point(323, 170)
        Me.txtTax.Name = "txtTax"
        Me.txtTax.ReadOnly = True
        Me.txtTax.Size = New System.Drawing.Size(72, 20)
        Me.txtTax.TabIndex = 24
        Me.txtTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(245, 173)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(45, 13)
        Me.Label6.TabIndex = 23
        Me.Label6.Text = "5% Tax:"
        '
        'txtTotal
        '
        Me.txtTotal.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.txtTotal.Location = New System.Drawing.Point(323, 196)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(72, 20)
        Me.txtTotal.TabIndex = 26
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(245, 199)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(34, 13)
        Me.Label7.TabIndex = 25
        Me.Label7.Text = "Total:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(78, 163)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 27
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(407, 230)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.txtTotal)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtTax)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtSubtotal)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtExtended4)
        Me.Controls.Add(Me.nudQuantity4)
        Me.Controls.Add(Me.txtPriceEach4)
        Me.Controls.Add(Me.txtItem4)
        Me.Controls.Add(Me.txtExtended3)
        Me.Controls.Add(Me.nudQuantity3)
        Me.Controls.Add(Me.txtPriceEach3)
        Me.Controls.Add(Me.txtItem3)
        Me.Controls.Add(Me.txtExtended2)
        Me.Controls.Add(Me.nudQuantity2)
        Me.Controls.Add(Me.txtPriceEach2)
        Me.Controls.Add(Me.txtItem2)
        Me.Controls.Add(Me.txtExtended1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.nudQuantity1)
        Me.Controls.Add(Me.txtPriceEach1)
        Me.Controls.Add(Me.txtItem1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Arithmetic Operators"
        CType(Me.nudQuantity1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudQuantity2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudQuantity4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.nudQuantity3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtItem1 As System.Windows.Forms.TextBox
    Friend WithEvents txtPriceEach1 As System.Windows.Forms.TextBox
    Friend WithEvents nudQuantity1 As System.Windows.Forms.NumericUpDown
    Friend WithEvents txtExtended1 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtExtended2 As System.Windows.Forms.TextBox
    Friend WithEvents nudQuantity2 As System.Windows.Forms.NumericUpDown
    Friend WithEvents txtPriceEach2 As System.Windows.Forms.TextBox
    Friend WithEvents txtItem2 As System.Windows.Forms.TextBox
    Friend WithEvents txtExtended4 As System.Windows.Forms.TextBox
    Friend WithEvents nudQuantity4 As System.Windows.Forms.NumericUpDown
    Friend WithEvents txtPriceEach4 As System.Windows.Forms.TextBox
    Friend WithEvents txtItem4 As System.Windows.Forms.TextBox
    Friend WithEvents txtExtended3 As System.Windows.Forms.TextBox
    Friend WithEvents nudQuantity3 As System.Windows.Forms.NumericUpDown
    Friend WithEvents txtPriceEach3 As System.Windows.Forms.TextBox
    Friend WithEvents txtItem3 As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtSubtotal As System.Windows.Forms.TextBox
    Friend WithEvents txtTax As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button

End Class
