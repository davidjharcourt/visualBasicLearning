﻿Public Class Form1

    Private Sub btnEvaluate_Click(sender As Object, e As EventArgs) Handles btnEvaluate.Click
        ' Get the values. This uses CType to convert string --> Fraction.
        Dim a As Fraction = txtA.Text
        Dim b As Fraction = txtB.Text

        ' Demonstrate the * operator.
        Dim a_times_b As Fraction = a * b
        txtAtimesB.Text = a_times_b.ToString()

        ' Demonstrate the / operator.
        Dim a_divided_by_b As Fraction = a / b
        txtAdividedbyB.Text = a_divided_by_b.ToString()
    End Sub
End Class
