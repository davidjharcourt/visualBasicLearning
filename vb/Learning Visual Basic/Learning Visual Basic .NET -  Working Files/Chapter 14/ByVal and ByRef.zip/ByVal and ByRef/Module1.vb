﻿Module Module1
    Public Sub CalculateStats(values() As Single, ByRef minimum As Single, ByRef maximum As Single, ByRef average As Single)
        ' Initialize the minimum, maximum, and total.
        minimum = values(0)
        maximum = values(0)
        Dim total As Single = 0

        ' Loop over the values.
        For i As Integer = 0 To values.Length - 1
            If minimum > values(i) Then minimum = values(i)
            If maximum < values(i) Then maximum = values(i)
            total += values(i)
        Next i

        ' Set the average.
        average = total / values.Length
    End Sub
End Module
