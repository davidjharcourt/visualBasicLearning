﻿Public Class Form1
    ' Update the date, time until Halloween, and time until the birthdate (if entered).
    Private Sub tmrTick_Tick(sender As Object, e As EventArgs) Handles tmrTick.Tick
        ' Display the current date.
        Dim now As Date = Date.Now
        lblGreeting.Text = "It is " & now.ToLongDateString() &
            " at " & now.ToLongTimeString()

        ' Get the time until Halloween.
        Dim halloween As Date = #10/31/2014#
        Dim till_halloween As TimeSpan = halloween - now
        lblDaysUntilHalloween.Text = "It is " &
            till_halloween.Days & " days, " &
            till_halloween.Hours & " hours, " &
            till_halloween.Minutes & " minutes, and " &
            till_halloween.Seconds & " seconds, until Halloween"

        ' Get the time until the birthdate.
        Dim birthdate As Date

        ' Use TryCatch to make sure the date it valid.
        If Date.TryParse(txtBirthday.Text, birthdate) Then
            ' The date is valid. Use it.
            Dim till_birthdate As TimeSpan = birthdate - now
            lblDaysUntilBirthdate.Text = "It is " &
                till_birthdate.Days & " days, " &
                till_birthdate.Hours & " hours, " &
                till_birthdate.Minutes & " minutes, and " &
                till_birthdate.Seconds & " seconds, until your birthday"
        Else
            ' The birthdate is invalid. Clear the birthdate label.
            lblDaysUntilBirthdate.Text = ""
        End If
    End Sub
End Class
