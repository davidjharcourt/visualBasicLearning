﻿Module GlobalStuff
    Public TheMainForm As Form1
    Public TheScheduleForm As ScheduleForm
    Public TheEventsForm As EventsForm
End Module
