﻿Public Class Form1

    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        ' Make an array of values.
        Dim values() As Single = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}

        ' Call the subroutine to calculate minimum, maximum, and average.
        Dim minimum, maximum, average As Single
        CalculateStats(values, minimum, maximum, average)

        ' Display the results.
        txtMinimum.Text = minimum
        txtMaximum.Text = maximum
        txtAverage.Text = average
    End Sub
End Class
