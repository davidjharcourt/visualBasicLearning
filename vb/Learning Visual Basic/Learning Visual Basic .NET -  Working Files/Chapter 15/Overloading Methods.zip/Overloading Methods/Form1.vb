﻿Public Class Form1
    ' Draw some ellipses and rectangles.
    Private Sub Form1_Paint(sender As Object, e As PaintEventArgs) Handles MyBase.Paint
        ' Make the drawing smoother. (Yes, this isn't covered in the video.)
        e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias

        ' Draw some shapes.
        MakeEllipse(e.Graphics, Brushes.LightBlue, Pens.Blue,
            10, 10, 200, 100)
        MakeRectangle(e.Graphics, Brushes.Pink, Pens.Red, 75, 25, 50, 200)
        MakeEllipse(e.Graphics, Pens.Red, 100, 50, 75, 100)
        MakeRectangle(e.Graphics, Pens.Black, 30, 160, 210, 50)
        MakeEllipse(e.Graphics, Brushes.LightGreen, 50, 100, 200, 30)
        MakeRectangle(e.Graphics, Brushes.Orange, 150, 150, 50, 50)
    End Sub

    ' Fill and outline an ellipse.
    Private Sub MakeEllipse(gr As Graphics, brush As Brush, pen As Pen,
            x As Integer, y As Integer, width As Integer, height As Integer)
        gr.FillEllipse(brush, x, y, width, height)
        gr.DrawEllipse(pen, x, y, width, height)
    End Sub

    ' Outline an ellipse.
    Private Sub MakeEllipse(gr As Graphics, pen As Pen,
            x As Integer, y As Integer, width As Integer, height As Integer)
        gr.DrawEllipse(pen, x, y, width, height)
    End Sub

    ' Fill an ellipse.
    Private Sub MakeEllipse(gr As Graphics, brush As Brush,
            x As Integer, y As Integer, width As Integer, height As Integer)
        gr.FillEllipse(brush, x, y, width, height)
    End Sub

    ' Fill and outline a rectangle.
    Private Sub MakeRectangle(gr As Graphics, brush As Brush, pen As Pen,
            x As Integer, y As Integer, width As Integer, height As Integer)
        gr.FillRectangle(brush, x, y, width, height)
        gr.DrawRectangle(pen, x, y, width, height)
    End Sub

    ' Outline a rectangle.
    Private Sub MakeRectangle(gr As Graphics, pen As Pen,
            x As Integer, y As Integer, width As Integer, height As Integer)
        gr.DrawRectangle(pen, x, y, width, height)
    End Sub

    ' Fill a rectangle.
    Private Sub MakeRectangle(gr As Graphics, brush As Brush,
            x As Integer, y As Integer, width As Integer, height As Integer)
        gr.FillRectangle(brush, x, y, width, height)
    End Sub
End Class
