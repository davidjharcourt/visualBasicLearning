﻿Public Interface IHouse
    Property NumBedrooms As Integer
    Property SquareFeet As Integer
End Interface
