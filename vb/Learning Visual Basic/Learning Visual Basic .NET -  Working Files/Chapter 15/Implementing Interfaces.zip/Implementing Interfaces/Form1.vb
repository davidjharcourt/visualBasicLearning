﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim people As New List(Of Person)()
        people.Add(New Person() With {.FirstName = "Chuck", .LastName = "Dint"})
        people.Add(New Person() With {.FirstName = "Betty", .LastName = "Eager"})
        people.Add(New Person() With {.FirstName = "Art", .LastName = "Carstairs"})
        people.Add(New Person() With {.FirstName = "Ed", .LastName = "Beech"})
        people.Add(New Person() With {.FirstName = "Darlene", .LastName = "Anderson"})

        ' Sort the people first name first.
        Dim fnf_comparer As New FirstNameFirstComparer()
        people.Sort(fnf_comparer)

        ' Sort the people last name first.
        Dim lnf_comparer As New LastNameFirstComparer()
        people.Sort(lnf_comparer)
    End Sub
End Class
