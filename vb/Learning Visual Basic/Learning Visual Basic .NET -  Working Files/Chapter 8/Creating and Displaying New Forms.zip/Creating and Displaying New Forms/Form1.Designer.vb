﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnNewUser = New System.Windows.Forms.Button()
        Me.btnNewCustomer = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnNewUser
        '
        Me.btnNewUser.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnNewUser.Location = New System.Drawing.Point(133, 37)
        Me.btnNewUser.Name = "btnNewUser"
        Me.btnNewUser.Size = New System.Drawing.Size(108, 23)
        Me.btnNewUser.TabIndex = 0
        Me.btnNewUser.Text = "New User"
        Me.btnNewUser.UseVisualStyleBackColor = True
        '
        'btnNewCustomer
        '
        Me.btnNewCustomer.Anchor = System.Windows.Forms.AnchorStyles.None
        Me.btnNewCustomer.Location = New System.Drawing.Point(133, 93)
        Me.btnNewCustomer.Name = "btnNewCustomer"
        Me.btnNewCustomer.Size = New System.Drawing.Size(108, 23)
        Me.btnNewCustomer.TabIndex = 1
        Me.btnNewCustomer.Text = "New Customer"
        Me.btnNewCustomer.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(375, 152)
        Me.Controls.Add(Me.btnNewCustomer)
        Me.Controls.Add(Me.btnNewUser)
        Me.Name = "Form1"
        Me.Text = "Creating and Displaying New Forms"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents btnNewUser As System.Windows.Forms.Button
    Friend WithEvents btnNewCustomer As System.Windows.Forms.Button

End Class
