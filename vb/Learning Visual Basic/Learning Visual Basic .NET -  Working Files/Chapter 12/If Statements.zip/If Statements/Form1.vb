﻿Public Class Form1
    ' Display a greeting.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If Date.Today.DayOfWeek = DayOfWeek.Monday Then
            MessageBox.Show("Sorry it's Monday")
        ElseIf Date.Today.DayOfWeek = DayOfWeek.Tuesday Then
            MessageBox.Show("It's only Tuesday")
        ElseIf Date.Today.DayOfWeek = DayOfWeek.Wednesday Then
            MessageBox.Show("Halfway there")
        ElseIf Date.Today.DayOfWeek = DayOfWeek.Thursday Then
            MessageBox.Show("It's Thursday")
        ElseIf Date.Today.DayOfWeek = DayOfWeek.Friday Then
            MessageBox.Show("Almost there!")
        Else
            MessageBox.Show("Yay! It's the weekend!")
        End If
    End Sub
End Class
