﻿Public Class Address
    Public Street, City, State, Zip As String
End Class
