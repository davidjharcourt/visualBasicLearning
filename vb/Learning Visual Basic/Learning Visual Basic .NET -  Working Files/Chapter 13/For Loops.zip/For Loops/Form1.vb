﻿Public Class Form1
    ' Display even numbers between 1 and 1,000 that are multiples of 3 or 5.
    Private Sub btnGo_Click(sender As Object, e As EventArgs) Handles btnGo.Click
        lstNumbers.Items.Clear()

        ' Loop through the even numbers.
        For i As Integer = 0 To 100 Step 2
            If i Mod 3 = 0 Then Continue For
            If i Mod 5 = 0 Then Continue For
            lstNumbers.Items.Add(i)
        Next i

        MessageBox.Show(lstNumbers.Items.Count & " numbers")
    End Sub
End Class
