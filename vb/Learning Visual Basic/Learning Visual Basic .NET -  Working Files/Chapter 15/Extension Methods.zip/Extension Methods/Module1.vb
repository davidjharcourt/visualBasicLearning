﻿Imports System.Runtime.CompilerServices

Module Module1
    ' Draw an ellipse.
    <Extension()>
    Public Sub DrawEllipse(rect As Rectangle, gr As Graphics, the_brush As Brush, the_pen As Pen)
        gr.FillEllipse(the_brush, rect)
        gr.DrawEllipse(the_pen, rect)
    End Sub
End Module
