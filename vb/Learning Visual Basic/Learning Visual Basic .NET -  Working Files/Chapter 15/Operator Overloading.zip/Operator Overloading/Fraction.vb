﻿Public Class Fraction
    Public Numerator, Denominator As Integer

    ' Initializing constructor.
    Public Sub New(new_numerator As Integer, new_denominator As Integer)
        Numerator = new_numerator
        Denominator = new_denominator
    End Sub

    ' Display the Fraction as a string.
    Public Overrides Function ToString() As String
        Return Numerator & " / " & Denominator
    End Function

    ' Convert the Fraction into a Double.
    Public Shared Widening Operator CType(fraction1 As Fraction) As Double
        Return fraction1.Numerator / fraction1.Denominator
    End Operator

    ' Convert a String into a Fraction.
    Public Shared Widening Operator CType(text As String) As Fraction
        ' Split the string at the / character.
        Dim pieces() As String = text.Split("/")

        ' Make the new fraction.
        Return New Fraction(pieces(0), pieces(1))
    End Operator

    ' Multiply two Fractions.
    Public Shared Operator *(fraction1 As Fraction, fraction2 As Fraction) As Fraction
        Return New Fraction(
            fraction1.Numerator * fraction2.Numerator,
            fraction1.Denominator * fraction2.Denominator)
    End Operator

    ' Multiply one Fraction by another.
    Public Shared Operator /(fraction1 As Fraction, fraction2 As Fraction) As Fraction
        Return New Fraction(
            fraction1.Numerator * fraction2.Denominator,
            fraction1.Denominator * fraction2.Numerator)
    End Operator
End Class
