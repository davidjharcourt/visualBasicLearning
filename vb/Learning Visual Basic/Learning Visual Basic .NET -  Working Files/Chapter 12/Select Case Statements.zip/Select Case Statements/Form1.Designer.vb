﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtScore = New System.Windows.Forms.TextBox()
        Me.btnGetGrade = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(38, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Score:"
        '
        'txtScore
        '
        Me.txtScore.Location = New System.Drawing.Point(56, 14)
        Me.txtScore.Name = "txtScore"
        Me.txtScore.Size = New System.Drawing.Size(58, 20)
        Me.txtScore.TabIndex = 1
        Me.txtScore.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'btnGetGrade
        '
        Me.btnGetGrade.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnGetGrade.Location = New System.Drawing.Point(197, 12)
        Me.btnGetGrade.Name = "btnGetGrade"
        Me.btnGetGrade.Size = New System.Drawing.Size(75, 23)
        Me.btnGetGrade.TabIndex = 2
        Me.btnGetGrade.Text = "Get Grade"
        Me.btnGetGrade.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AcceptButton = Me.btnGetGrade
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 50)
        Me.Controls.Add(Me.btnGetGrade)
        Me.Controls.Add(Me.txtScore)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Select Case Statements"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtScore As System.Windows.Forms.TextBox
    Friend WithEvents btnGetGrade As System.Windows.Forms.Button

End Class
