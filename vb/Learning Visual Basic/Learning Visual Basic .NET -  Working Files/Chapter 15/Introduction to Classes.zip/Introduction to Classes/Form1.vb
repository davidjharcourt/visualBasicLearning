﻿Public Class Form1

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Make some Persons.
        Dim ann As New Person()
        ann.FirstName = "Ann"
        ann.LastName = "Archer"
        ann.MailingAddress = New Address()
        ann.MailingAddress.Street = "1313 Mockingbird Ln"
        ann.MailingAddress.City = "Mockingbird Heights"
        ann.MailingAddress.Street = "CA"
        ann.MailingAddress.Zip = "92001"

        Dim bob As New Person() With
        {
            .FirstName = "Bob",
            .LastName = "Baker",
            .MailingAddress = New Address() With
            {
                .Street = "1337 Leet St",
                .City = "Bugsville",
                .State = "HI",
                .Zip = "98765"
            }
        }

        ' Stop and use IntelliSense to examine the Persons.
        Stop
    End Sub
End Class
