﻿Public Class Form1
    Private Total As Integer = 0

    ' Add the new value to the total.
    Private Sub btnAdd_Click(sender As Object, e As EventArgs) Handles btnAdd.Click
        ' Add the value to Total.
        Total += txtValue.Text

        ' Display the new total.
        txtTotal.Text = Total
    End Sub
End Class
