﻿Public Class Person
    Public FirstName, LastName As String

    Public Sub SayYourName()
        MessageBox.Show(FirstName & " " & LastName)
    End Sub
End Class

Public Class Employee
    Inherits Person

    Public EmployeeId As Integer
End Class

Public Enum StudentYears
    Freshman
    Sophomore
    Junior
    Senior
End Enum

Public Class Student
    Inherits Person

    Public Year As StudentYears
End Class

Public Class Manager
    Inherits Employee

    Public Department As String
End Class