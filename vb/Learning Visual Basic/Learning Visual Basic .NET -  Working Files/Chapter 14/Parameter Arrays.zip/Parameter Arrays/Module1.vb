﻿Module Module1

    ' Display a student's grade.
    Public Sub ShowGrade(student As String, ParamArray test_scores() As Integer)
        ' Add up the test scores.
        Dim total As Integer = 0
        For Each score As Integer In test_scores
            total += score
        Next score

        ' Calculate the average.
        Dim average As Single = total
        If test_scores.Length > 0 Then
            ' There are test scores.
            average /= test_scores.Length
        End If

        ' Find the letter grade.
        Dim letter_grade As String
        Select Case average
            Case Is >= 90
                letter_grade = "A"
            Case Is >= 80
                letter_grade = "B"
            Case Is >= 70
                letter_grade = "C"
            Case Is >= 60
                letter_grade = "D"
            Case Else
                letter_grade = "F"
        End Select

        ' Display the results.
        MessageBox.Show(student & " has a " & average &
            " average giving a grade of " & letter_grade)
    End Sub

End Module
