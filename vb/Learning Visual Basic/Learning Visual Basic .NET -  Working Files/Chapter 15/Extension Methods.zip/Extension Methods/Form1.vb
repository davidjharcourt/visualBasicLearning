﻿Public Class Form1
    ' Draw some ellipses.
    Private Sub Form1_Paint(sender As Object, e As PaintEventArgs) Handles Me.Paint
        e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias

        Dim rect1 As New Rectangle(10, 10, 200, 100)
        rect1.DrawEllipse(e.Graphics, Brushes.Pink, Pens.Orange)

        Dim rect2 As New Rectangle(100, 50, 100, 200)
        rect2.DrawEllipse(e.Graphics, Brushes.LightBlue, Pens.Blue)

        Dim rect3 As New Rectangle(70, 100, 75, 75)
        rect3.DrawEllipse(e.Graphics, Brushes.LightGreen, Pens.Green)
    End Sub
End Class
