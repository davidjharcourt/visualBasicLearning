﻿Public Class Form1
    ' A list of IHouse.
    Private Houses As New List(Of IHouse)()

    ' A list of Boat.
    Private Boats As New List(Of Boat)()

    ' Make some house boats.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim houseboat1 As New HouseBoat() With {.HorsePower = 100, .NumBedrooms = 1, .SquareFeet = 100}
        Dim houseboat2 As New HouseBoat() With {.HorsePower = 200, .NumBedrooms = 2, .SquareFeet = 200}
        Dim houseboat3 As New HouseBoat() With {.HorsePower = 300, .NumBedrooms = 3, .SquareFeet = 300}

        ' Add them to the lists.
        Houses.Add(houseboat1)
        Houses.Add(houseboat2)
        Houses.Add(houseboat3)

        Boats.Add(houseboat1)
        Boats.Add(houseboat2)
        Boats.Add(houseboat3)

        ' Display their information.
        For Each a_house As IHouse In Houses
            lstHouses.Items.Add(a_house.NumBedrooms & " BR, " & a_house.SquareFeet & " SF")
        Next a_house

        For Each a_boat As Boat In Boats
            lstBoats.Items.Add(a_boat.HorsePower & " HP")
        Next a_boat
    End Sub
End Class
