﻿Imports System.IO

Public Class Form1
    ' Start in the program's startup path.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtDirectory.Text = Application.StartupPath
    End Sub

    ' Let the user browse for a directory.
    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        fbdDirectory.SelectedPath = txtDirectory.Text
        If fbdDirectory.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtDirectory.Text = fbdDirectory.SelectedPath
        End If
    End Sub

    ' List files.
    Private Sub btnListFiles_Click(sender As Object, e As EventArgs) Handles btnListFiles.Click
        ' See if we should search recursively.
        Dim search_option As SearchOption = SearchOption.TopDirectoryOnly
        If chkRecursive.Checked Then search_option = SearchOption.AllDirectories

        ' List the files.
        clbFiles.Items.Clear()
        For Each filename As String In Directory.EnumerateFiles(txtDirectory.Text,
                    txtPattern.Text, search_option)
            clbFiles.Items.Add(filename)
        Next filename
    End Sub

    ' Delete the checked files.
    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        If clbFiles.CheckedItems.Count = 0 Then Return

        If MessageBox.Show("Are you sure you want to permanently delete the " &
                clbFiles.CheckedItems.Count & " selected files?",
                "Confirm?", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            ' Delete the files.
            For Each filename As String In clbFiles.CheckedItems
                Try
                    File.Delete(filename)
                Catch ex As Exception
                    MessageBox.Show(ex.Message)
                End Try
            Next filename

            ' Clear the list box.
            clbFiles.Items.Clear()
        End If
    End Sub
End Class
