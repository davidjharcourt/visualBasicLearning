﻿Public Class Form1
    ' All of the paragraphs we need to print.
    Private Paragraphs() As String =
    {
        "Lorem ipsum dolor sit amet, consectetur adipiscing elit. In accumsan enim et velit rutrum auctor. Sed at massa non ligula rhoncus varius. Fusce id blandit ligula. Vivamus id orci sodales, volutpat nisl auctor, vulputate mauris. Sed lectus lectus, luctus ut consectetur sed, consequat id massa. Praesent dui felis, consequat vitae consectetur sed, fringilla in turpis. Nam luctus turpis in dui convallis, eget commodo velit fermentum. In hac habitasse platea dictumst.",
        "Phasellus quis facilisis ipsum. Integer accumsan odio sed auctor suscipit. Donec tempus, odio vel egestas fermentum, orci felis ultrices est, sed porttitor sem sem a erat. Vestibulum consequat, quam tristique scelerisque tincidunt, ligula arcu tristique purus, sed tincidunt tortor leo a augue. In mollis sollicitudin tellus vel vehicula.",
        "Fusce viverra nisl id sem convallis, vitae molestie felis aliquam. Aliquam non nibh semper, tristique metus aliquet, pellentesque nibh. Morbi sed vestibulum justo. Aliquam erat volutpat. Curabitur ac mi vel metus hendrerit lacinia. Suspendisse et magna sem. Duis molestie consectetur turpis eu congue. Vivamus rutrum tellus ut fermentum congue.",
        "Vivamus vulputate sapien ut justo porttitor, sed tempor leo porttitor. Nam vestibulum hendrerit massa, sit amet porttitor lectus ornare ac.",
        "Integer erat tortor, auctor ut arcu sed, vestibulum interdum diam. Vivamus venenatis orci elit, a rutrum odio commodo eu. Praesent ut tincidunt ligula, ut aliquet diam. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas.",
        "Suspendisse ut massa libero. Mauris aliquam massa sem. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vestibulum placerat porta purus.",
        "Donec in venenatis augue, eget laoreet massa. Sed nec imperdiet nulla. Nullam consequat sodales mauris, eget suscipit nisl iaculis a. Vestibulum ut lectus magna. Etiam a sapien et orci interdum ornare et in dolor.",
        "Etiam faucibus ultricies posuere. Etiam egestas nulla sed arcu varius pretium. Proin at ornare lorem."
    }

    ' The paragraphs we have yet to print.
    Private ParagraphsToPrint As List(Of String)

    ' The next page number.
    Private NextPage As Integer

    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        ' Add all paragraphs to the paragraphs yet to print.
        ParagraphsToPrint = New List(Of String)(Paragraphs)

        ' Start with page number 1.
        NextPage = 1

        ' Display the dialog.
        ppdList.ShowDialog()
    End Sub

    ' Print a page.
    Private Sub pdocList_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles pdocList.PrintPage
        Const font_size As Single = 24
        Const line_size As Single = 1.5 * font_size

        Using the_font As New Font("Times New Roman", font_size)
            Using string_format As New StringFormat()
                ' Don't display partial lines.
                string_format.FormatFlags = StringFormatFlags.LineLimit

                ' Start at the top margin.
                Dim Y As Single = e.MarginBounds.Top

                ' Draw the page number.
                e.Graphics.DrawString(NextPage, the_font, Brushes.Black,
                    e.MarginBounds.Right + 30, e.MarginBounds.Top - 50)

                Do While ParagraphsToPrint.Count > 0
                    ' Get the next paragraph.
                    Dim next_paragraph = ParagraphsToPrint(0)
                    ParagraphsToPrint.RemoveAt(0)

                    ' See how much of the paragraph will fit in the available area.
                    Dim available_size = New SizeF(e.MarginBounds.Width, e.MarginBounds.Bottom - Y)
                    Dim chars_fitted, lines_filled As Integer
                    Dim paragraph_size As SizeF = e.Graphics.MeasureString(
                        next_paragraph, the_font, available_size,
                        string_format, chars_fitted, lines_filled)

                    ' See how much of the paragraph will fit.
                    If chars_fitted < next_paragraph.Length Then
                        ' Save the remainder of the paragraph in the ParagraphsToPrint list.
                        ParagraphsToPrint.Insert(0, next_paragraph.Substring(chars_fitted))

                        ' Set next_paragraph equal to whatever will fit.
                        next_paragraph = next_paragraph.Substring(0, chars_fitted)
                    End If

                    ' Print as much of the paragraph as will fit.
                    Dim rect As New Rectangle(e.MarginBounds.Left, Y, paragraph_size.Width, paragraph_size.Height)
                    e.Graphics.DrawString(next_paragraph, the_font, Brushes.Black, rect, string_format)

                    ' Draw the paragraph's rectangle (for debugging).
                    'e.Graphics.DrawRectangle(Pens.Blue, rect)

                    ' Move past the paragraph.
                    Y += paragraph_size.Height + line_size

                    ' If we've run out of room, break out of the loop.
                    If Y + line_size > e.MarginBounds.Bottom Then Exit Do
                Loop

                e.HasMorePages = (ParagraphsToPrint.Count > 0)
            End Using
        End Using
    End Sub
End Class
