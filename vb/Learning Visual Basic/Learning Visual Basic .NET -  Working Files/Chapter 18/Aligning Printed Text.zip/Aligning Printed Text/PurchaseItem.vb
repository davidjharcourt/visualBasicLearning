﻿Public Class PurchaseItem
    Public Description As String
    Public Quantity As Integer
    Public UnitPrice As Decimal

    ' Initializing constructor.
    Public Sub New(descr As String, qty As Integer, unit_price As Decimal)
        Description = descr
        Quantity = qty
        UnitPrice = unit_price
    End Sub
End Class
