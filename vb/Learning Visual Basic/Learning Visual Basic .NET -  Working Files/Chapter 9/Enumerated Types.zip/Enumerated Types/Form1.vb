﻿Public Class Form1
    ' Types of allowed meals.
    Private Enum MealTypes
        Breakfast
        Brunch
        Tiffin = Brunch
        Dinner
        Supper = Dinner
    End Enum

    ' Set a meal type. (Just to use IntelliSense to see what choices are available.)
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim meal As MealTypes
        meal = MealTypes.Tiffin
    End Sub
End Class
