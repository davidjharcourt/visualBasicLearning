﻿Public Class Form1

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click
        Const tax_rate As Decimal = 0.05

        ' Get the user's inputs.
        Dim quantity1 As Decimal = nudQuantity1.Value
        Dim quantity2 As Decimal = nudQuantity2.Value
        Dim quantity3 As Decimal = nudQuantity3.Value
        Dim quantity4 As Decimal = nudQuantity4.Value
        Dim price1 As Decimal = txtPriceEach1.Text
        Dim price2 As Decimal = txtPriceEach2.Text
        Dim price3 As Decimal = txtPriceEach3.Text
        Dim price4 As Decimal = txtPriceEach4.Text

        ' Calculate results.
        Dim extended1 As Decimal = quantity1 * price1
        Dim extended2 As Decimal = quantity2 * price2
        Dim extended3 As Decimal = quantity3 * price3
        Dim extended4 As Decimal = quantity4 * price4
        Dim subtotal As Decimal = extended1 + extended2 + extended3 + extended4
        Dim tax As Decimal = subtotal * tax_rate
        Dim total As Decimal = subtotal + tax

        ' Display results.
        txtExtended1.Text = extended1.ToString("C")
        txtExtended2.Text = extended2.ToString("C")
        txtExtended3.Text = extended3.ToString("C")
        txtExtended4.Text = extended4.ToString("C")
        txtSubtotal.Text = subtotal.ToString("C")
        txtTax.Text = tax.ToString("C")
        txtTotal.Text = total.ToString("C")
    End Sub
End Class
