﻿Public Class Student
    Public Name, Grade As String
End Class
