﻿Public Class Form1
    ' Perform some string calculations.
    Private Sub btnCheck_Click(sender As Object, e As EventArgs) Handles btnCheck.Click
        ' Get the user's text and the target.
        Dim text As String = txtText.Text
        Dim target As String = txtTarget.Text

        ' Calculate results.
        Dim result As String = ""

        ' Convert the text and target to lower case.
        text = text.ToLower()
        target = target.ToLower()

        ' Display the string's length.
        result &= "The string holds " & text.Length & " characters." & vbCrLf

        ' Display the text in upper case.
        result &= text.ToUpper() & vbCrLf

        ' See if the target occurs in the text.
        If text.Contains(target) Then
            result &= "The text contains the target." & vbCrLf
        End If

        ' Find the target's location(s).
        result &= "First occurrence: " & text.IndexOf(target) & vbCrLf
        result &= "Last occurrence: " & text.LastIndexOf(target) & vbCrLf

        ' Display the text between the two occurrances.
        Dim first_index As Integer = text.IndexOf(target) + target.Length
        Dim last_index As Integer = text.LastIndexOf(target) - 1
        Dim length As Integer = last_index - first_index
        Dim substring As String = text.Substring(first_index, length)
        substring = substring.Trim()
        result &= "[" & substring & "]" & vbCrLf

        ' Replace the target with "***."
        result &= text.Replace(target, "***")

        ' Display the result.
        lblResult.Text = result
    End Sub
End Class
