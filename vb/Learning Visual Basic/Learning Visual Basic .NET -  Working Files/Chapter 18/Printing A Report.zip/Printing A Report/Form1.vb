﻿Public Class Form1
    ' The items we will print.
    Private Items As New List(Of PurchaseItem)()

    ' Create some items to print.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' I'll use a loop to create enough items to cause a page break.
        For i As Integer = 1 To 10
            Items.Add(New PurchaseItem("Notebook", 6, 1.15))
            Items.Add(New PurchaseItem("Cookies", 12, 0.5))
            Items.Add(New PurchaseItem("Pencils, 10 ct", 10, 1.57))
            Items.Add(New PurchaseItem("Soda, 6 pack", 1, 2.5))
            Items.Add(New PurchaseItem("Whiteboard Eraser", 2, 3.15))
            Items.Add(New PurchaseItem("Pens, blue, roller tip, 25 ct", 2, 3.49))
            Items.Add(New PurchaseItem("Pens, green, roller tip, 25 ct", 1, 3.49))
            Items.Add(New PurchaseItem("Pens, red, roller tip, 25 ct", 1, 3.49))
            Items.Add(New PurchaseItem("Highlighters, assorted colors", 1, 2.76))
            Items.Add(New PurchaseItem("Copy Paper, 20 lb, case", 1, 34.99))
        Next i
    End Sub

    ' Start printing.
    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        ppdReport.ShowDialog()
    End Sub

    ' The next page number to print.
    Private NextPage As Integer = 1

    ' The index of the next item to print.
    Private NextItem As Integer

    ' Keep track of the total price across all pages.
    Private TotalCost As Decimal

    ' Generate a page.
    Private Sub pdocReport_PrintPage(sender As Object, e As Printing.PrintPageEventArgs) Handles pdocReport.PrintPage
        ' Some formatting and calculation constants.
        Const tax_rate As Decimal = 0.05
        Const page_number_size As Single = 16
        Const header_font_size As Single = 16
        Const header_line_spacing As Single = header_font_size * 2
        Const item_font_size As Single = 16
        Const item_line_spacing As Single = item_font_size * 1.5

        ' X coordinates of the columns.
        Dim x_item_number As Single = e.MarginBounds.Left   ' Item number.
        Dim x_description As Single = x_item_number + 50    ' Description.
        Dim x_quantity As Single = x_description + 350      ' Quantity.
        Dim x_unit_price As Single = x_quantity + 75        ' Unit price.
        Dim x_extended_price As Single = x_unit_price + 75  ' Extended price.

        ' If this is the first page, then we are starting a new printout.
        ' In that case, reset TotalCost to 0 and NextItem to 0.
        If NextPage = 1 Then
            TotalCost = 0
            NextItem = 0
        End If

        ' Keep track of our Y position on this page.
        Dim Y As Integer = e.MarginBounds.Top

        ' Print the page number.
        Using page_number_font As New Font("Times New Roman", page_number_size)
            e.Graphics.DrawString(NextPage, page_number_font, Brushes.Blue,
                e.MarginBounds.Right, e.MarginBounds.Top - page_number_size * 2)
        End Using

        ' Print the column headers.
        Using header_font As New Font("Times New Roman", header_font_size)
            e.Graphics.DrawString("#", header_font, Brushes.Blue, x_item_number, Y)
            e.Graphics.DrawString("Description", header_font, Brushes.Blue, x_description, Y)
            e.Graphics.DrawString("Qty", header_font, Brushes.Blue, x_quantity, Y)
            e.Graphics.DrawString("Price", header_font, Brushes.Blue, x_unit_price, Y)
            e.Graphics.DrawString("Ext", header_font, Brushes.Blue, x_extended_price, Y)
            Y += header_line_spacing
        End Using

        ' Print the items that fit in this page.
        Using item_font As New Font("Times New Roman", item_font_size)
            Do While NextItem < Items.Count
                ' Calculate the item's extended cost.
                Dim extended_price As Decimal = Items(NextItem).Quantity * Items(NextItem).UnitPrice
                TotalCost += extended_price

                ' Print the next item.
                e.Graphics.DrawString(NextItem + 1, item_font, Brushes.Black, x_item_number, Y)
                e.Graphics.DrawString(Items(NextItem).Description, item_font, Brushes.Black, x_description, Y)
                e.Graphics.DrawString(Items(NextItem).Quantity, item_font, Brushes.Black, x_quantity, Y)
                e.Graphics.DrawString(Items(NextItem).UnitPrice.ToString("C"), item_font, Brushes.Black, x_unit_price, Y)
                e.Graphics.DrawString(extended_price.ToString("C"), item_font, Brushes.Black, x_extended_price, Y)

                ' Move to the next item.
                NextItem += 1

                ' Move down a line.
                Y += item_line_spacing

                ' If we're out of room on the page, break out of the loop.
                If Y > e.MarginBounds.Bottom - item_font_size Then Exit Do
            Loop

            ' Increment the page number.
            NextPage += 1

            ' We're either out of items or out of room. See which.
            If NextItem >= Items.Count Then
                ' We're out of items. See if we have room for the total.
                If Y + 4 * item_line_spacing <= e.MarginBounds.Bottom Then
                    ' We have room for the total. Display it.
                    Y += item_line_spacing

                    ' Subtotal.
                    e.Graphics.DrawString("Subtotal", item_font, Brushes.Blue, x_quantity, Y)
                    e.Graphics.DrawString(TotalCost.ToString("C"), item_font, Brushes.Blue, x_extended_price, Y)
                    Y += item_line_spacing

                    ' Tax.
                    Dim tax As Decimal = TotalCost * tax_rate
                    e.Graphics.DrawString("Tax", item_font, Brushes.Blue, x_quantity, Y)
                    e.Graphics.DrawString(tax.ToString("C"), item_font, Brushes.Blue, x_extended_price, Y)
                    Y += item_line_spacing

                    ' Grand total.
                    TotalCost += tax
                    e.Graphics.DrawString("Total", item_font, Brushes.Blue, x_quantity, Y)
                    e.Graphics.DrawString(TotalCost.ToString("C"), item_font, Brushes.Blue, x_extended_price, Y)

                    ' We are done.
                    e.HasMorePages = False
                    NextPage = 1
                Else
                    ' We didn't have room for the total. We need another page.
                    e.HasMorePages = True
                End If
            Else
                ' We are not out of items. We need another page.
                e.HasMorePages = True
            End If
        End Using
    End Sub
End Class
