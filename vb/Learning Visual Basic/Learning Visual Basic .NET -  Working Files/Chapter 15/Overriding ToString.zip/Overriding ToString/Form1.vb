﻿Public Class Form1
    ' Add some people to the ListBox.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        lstPeople.Items.Add(New Person() With {.FirstName = "Art", .LastName = "Ant", .Email = "ann@ant.com"})
        lstPeople.Items.Add(New Person() With {.FirstName = "Bea", .LastName = "Bonnie", .Email = "bb@somewhere.com"})
        lstPeople.Items.Add(New Person() With {.FirstName = "Cid", .LastName = "Carruthers", .Email = "CidCarruthers@gmail.com"})
        lstPeople.Items.Add(New Person() With {.FirstName = "Diana", .LastName = "Dother", .Email = "DianaD@msn.com"})
    End Sub
End Class
