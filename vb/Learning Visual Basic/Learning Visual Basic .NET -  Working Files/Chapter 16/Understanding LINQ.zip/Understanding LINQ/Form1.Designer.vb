﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lstA = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lstAbc = New System.Windows.Forms.ListBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lstFailing = New System.Windows.Forms.ListBox()
        Me.SuspendLayout()
        '
        'lstA
        '
        Me.lstA.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstA.FormattingEnabled = True
        Me.lstA.IntegralHeight = False
        Me.lstA.Location = New System.Drawing.Point(12, 25)
        Me.lstA.Name = "lstA"
        Me.lstA.Size = New System.Drawing.Size(260, 50)
        Me.lstA.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(62, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "A Students:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 87)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(109, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "A, B, and C Students:"
        '
        'lstAbc
        '
        Me.lstAbc.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstAbc.FormattingEnabled = True
        Me.lstAbc.IntegralHeight = False
        Me.lstAbc.Location = New System.Drawing.Point(12, 103)
        Me.lstAbc.Name = "lstAbc"
        Me.lstAbc.Size = New System.Drawing.Size(260, 93)
        Me.lstAbc.TabIndex = 2
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 209)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(85, 13)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Failing Students:"
        '
        'lstFailing
        '
        Me.lstFailing.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.lstFailing.FormattingEnabled = True
        Me.lstFailing.IntegralHeight = False
        Me.lstFailing.Location = New System.Drawing.Point(12, 225)
        Me.lstFailing.Name = "lstFailing"
        Me.lstFailing.Size = New System.Drawing.Size(260, 50)
        Me.lstFailing.TabIndex = 4
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 288)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.lstFailing)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lstAbc)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstA)
        Me.Name = "Form1"
        Me.Text = "Understanding LINQ"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lstA As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents lstAbc As System.Windows.Forms.ListBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lstFailing As System.Windows.Forms.ListBox

End Class
