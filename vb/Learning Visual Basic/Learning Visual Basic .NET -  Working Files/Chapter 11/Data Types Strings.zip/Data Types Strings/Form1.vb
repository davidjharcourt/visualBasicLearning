﻿Public Class Form1
    ' Display a summary of hours worked.
    Private Sub btnEnter_Click(sender As Object, e As EventArgs) Handles btnEnter.Click
        ' Get the monetary amount.
        Dim money As Decimal
        If Not Decimal.TryParse(txtMoneyAmount.Text, money) Then
            MessageBox.Show("Please enter a monetary amount")
            txtMoneyAmount.Focus()
            Return
        End If

        ' Build the result.
        Dim result As String
        result = txtFirstName.Text & " " & txtLastName.Text
        result &= " worked" & vbCrLf
        result &= nudHoursWorked.Value & " hours today"
        result &= " and earned " & money.ToString("C")

        ' Display the result.
        txtResult.Text = result
    End Sub
End Class
