﻿Imports System.IO.File

Public Class Form1
    ' Start with the executable file.
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        txtFile.Text = Application.ExecutablePath
    End Sub

    ' Let the user browse for a file.
    Private Sub btnBrowse_Click(sender As Object, e As EventArgs) Handles btnBrowse.Click
        ofdFile.FileName = txtFile.Text
        If ofdFile.ShowDialog() = Windows.Forms.DialogResult.OK Then
            txtFile.Text = ofdFile.FileName
        End If
    End Sub

    ' Get the file's times.
    Private Sub btnGetTime_Click(sender As Object, e As EventArgs) Handles btnGetTime.Click
        txtCreated.Text = GetCreationTime(txtFile.Text)
        txtLastAccess.Text = GetLastAccessTime(txtFile.Text)
        txtLastWrite.Text = GetLastWriteTime(txtFile.Text)
    End Sub

    ' Set the file's times.
    Private Sub btnSetTimes_Click(sender As Object, e As EventArgs) Handles btnSetTimes.Click
        Try
            SetCreationTime(txtFile.Text, txtCreated.Text)
            SetLastAccessTime(txtFile.Text, txtLastAccess.Text)
            SetLastWriteTime(txtFile.Text, txtLastWrite.Text)

            txtCreated.Clear()
            txtLastAccess.Clear()
            txtLastWrite.Clear()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
End Class
