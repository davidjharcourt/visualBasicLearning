﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDequeue = New System.Windows.Forms.Button()
        Me.btnEnqueue = New System.Windows.Forms.Button()
        Me.txtPriority = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtItem = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtQuantity = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'btnDequeue
        '
        Me.btnDequeue.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.btnDequeue.Location = New System.Drawing.Point(197, 41)
        Me.btnDequeue.Name = "btnDequeue"
        Me.btnDequeue.Size = New System.Drawing.Size(75, 23)
        Me.btnDequeue.TabIndex = 4
        Me.btnDequeue.Text = "Dequeue"
        Me.btnDequeue.UseVisualStyleBackColor = True
        '
        'btnEnqueue
        '
        Me.btnEnqueue.Location = New System.Drawing.Point(197, 12)
        Me.btnEnqueue.Name = "btnEnqueue"
        Me.btnEnqueue.Size = New System.Drawing.Size(75, 23)
        Me.btnEnqueue.TabIndex = 3
        Me.btnEnqueue.Text = "Enqueue"
        Me.btnEnqueue.UseVisualStyleBackColor = True
        '
        'txtPriority
        '
        Me.txtPriority.Location = New System.Drawing.Point(59, 66)
        Me.txtPriority.Name = "txtPriority"
        Me.txtPriority.Size = New System.Drawing.Size(100, 20)
        Me.txtPriority.TabIndex = 2
        Me.txtPriority.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 69)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(41, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "Priority:"
        '
        'txtItem
        '
        Me.txtItem.Location = New System.Drawing.Point(59, 14)
        Me.txtItem.Name = "txtItem"
        Me.txtItem.Size = New System.Drawing.Size(100, 20)
        Me.txtItem.TabIndex = 0
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(30, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Item:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 43)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 13)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Quantity:"
        '
        'txtQuantity
        '
        Me.txtQuantity.Location = New System.Drawing.Point(59, 40)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.Size = New System.Drawing.Size(100, 20)
        Me.txtQuantity.TabIndex = 1
        Me.txtQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Form1
        '
        Me.AcceptButton = Me.btnEnqueue
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.CancelButton = Me.btnDequeue
        Me.ClientSize = New System.Drawing.Size(299, 127)
        Me.Controls.Add(Me.txtQuantity)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.btnDequeue)
        Me.Controls.Add(Me.btnEnqueue)
        Me.Controls.Add(Me.txtPriority)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtItem)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form1"
        Me.Text = "Building Generic Classes"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnDequeue As System.Windows.Forms.Button
    Friend WithEvents btnEnqueue As System.Windows.Forms.Button
    Friend WithEvents txtPriority As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtItem As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtQuantity As System.Windows.Forms.TextBox

End Class
