﻿Public Class LastNameFirstComparer
    Implements IComparer(Of Person)

    Public Function Compare(x As Person, y As Person) As Integer Implements IComparer(Of Person).Compare
        Dim x_name = x.LastName & " " & x.FirstName
        Dim y_name = y.LastName & " " & y.FirstName
        Return x_name.CompareTo(y_name)
    End Function
End Class
