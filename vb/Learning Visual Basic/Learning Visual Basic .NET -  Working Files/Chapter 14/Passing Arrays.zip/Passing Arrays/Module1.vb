﻿Module Module1

    ' Make the indicated number of strings.
    Public Sub MakeStrings(number As Integer, text As String, ByRef strings() As String)
        ReDim strings(0 To number - 1)
        For i As Integer = 0 To number - 1
            strings(i) = text
        Next i
    End Sub

    ' Make the indicated number of strings with a function.
    Public Function MakeStringsFunction(number As Integer, text As String) As String()
        ' Create an array to hold the result.
        Dim strings(0 To number - 1) As String

        ' Create the strings.
        ReDim strings(0 To number - 1)
        For i As Integer = 0 To number - 1
            strings(i) = text
        Next i

        ' Return the array.
        Return strings
    End Function

End Module
