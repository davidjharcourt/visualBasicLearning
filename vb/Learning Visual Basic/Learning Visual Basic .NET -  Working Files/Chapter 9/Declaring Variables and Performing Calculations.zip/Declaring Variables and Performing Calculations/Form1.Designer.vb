﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtAmount = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txt10PctTip = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txt10PctTotal = New System.Windows.Forms.TextBox()
        Me.txt15PctTotal = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.txt15PctTip = New System.Windows.Forms.TextBox()
        Me.txt20PctTotal = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.txt20PctTip = New System.Windows.Forms.TextBox()
        Me.txt25PctTotal = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txt25PctTip = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'txtAmount
        '
        Me.txtAmount.Location = New System.Drawing.Point(64, 14)
        Me.txtAmount.Name = "txtAmount"
        Me.txtAmount.Size = New System.Drawing.Size(100, 20)
        Me.txtAmount.TabIndex = 0
        Me.txtAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 17)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Amount:"
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(195, 12)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.btnCalculate.TabIndex = 2
        Me.btnCalculate.Text = "Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 100)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(27, 13)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "10%"
        '
        'txt10PctTip
        '
        Me.txt10PctTip.Location = New System.Drawing.Point(64, 97)
        Me.txt10PctTip.Name = "txt10PctTip"
        Me.txt10PctTip.ReadOnly = True
        Me.txt10PctTip.Size = New System.Drawing.Size(100, 20)
        Me.txt10PctTip.TabIndex = 3
        Me.txt10PctTip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label3
        '
        Me.Label3.Location = New System.Drawing.Point(64, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 21)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Tip"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(170, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 21)
        Me.Label4.TabIndex = 7
        Me.Label4.Text = "Total"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'txt10PctTotal
        '
        Me.txt10PctTotal.Location = New System.Drawing.Point(170, 97)
        Me.txt10PctTotal.Name = "txt10PctTotal"
        Me.txt10PctTotal.ReadOnly = True
        Me.txt10PctTotal.Size = New System.Drawing.Size(100, 20)
        Me.txt10PctTotal.TabIndex = 6
        Me.txt10PctTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt15PctTotal
        '
        Me.txt15PctTotal.Location = New System.Drawing.Point(170, 123)
        Me.txt15PctTotal.Name = "txt15PctTotal"
        Me.txt15PctTotal.ReadOnly = True
        Me.txt15PctTotal.Size = New System.Drawing.Size(100, 20)
        Me.txt15PctTotal.TabIndex = 10
        Me.txt15PctTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 126)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(27, 13)
        Me.Label5.TabIndex = 9
        Me.Label5.Text = "15%"
        '
        'txt15PctTip
        '
        Me.txt15PctTip.Location = New System.Drawing.Point(64, 123)
        Me.txt15PctTip.Name = "txt15PctTip"
        Me.txt15PctTip.ReadOnly = True
        Me.txt15PctTip.Size = New System.Drawing.Size(100, 20)
        Me.txt15PctTip.TabIndex = 8
        Me.txt15PctTip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt20PctTotal
        '
        Me.txt20PctTotal.Location = New System.Drawing.Point(170, 149)
        Me.txt20PctTotal.Name = "txt20PctTotal"
        Me.txt20PctTotal.ReadOnly = True
        Me.txt20PctTotal.Size = New System.Drawing.Size(100, 20)
        Me.txt20PctTotal.TabIndex = 13
        Me.txt20PctTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 152)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(27, 13)
        Me.Label6.TabIndex = 12
        Me.Label6.Text = "20%"
        '
        'txt20PctTip
        '
        Me.txt20PctTip.Location = New System.Drawing.Point(64, 149)
        Me.txt20PctTip.Name = "txt20PctTip"
        Me.txt20PctTip.ReadOnly = True
        Me.txt20PctTip.Size = New System.Drawing.Size(100, 20)
        Me.txt20PctTip.TabIndex = 11
        Me.txt20PctTip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'txt25PctTotal
        '
        Me.txt25PctTotal.Location = New System.Drawing.Point(170, 175)
        Me.txt25PctTotal.Name = "txt25PctTotal"
        Me.txt25PctTotal.ReadOnly = True
        Me.txt25PctTotal.Size = New System.Drawing.Size(100, 20)
        Me.txt25PctTotal.TabIndex = 16
        Me.txt25PctTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(12, 178)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(27, 13)
        Me.Label7.TabIndex = 15
        Me.Label7.Text = "25%"
        '
        'txt25PctTip
        '
        Me.txt25PctTip.Location = New System.Drawing.Point(64, 175)
        Me.txt25PctTip.Name = "txt25PctTip"
        Me.txt25PctTip.ReadOnly = True
        Me.txt25PctTip.Size = New System.Drawing.Size(100, 20)
        Me.txt25PctTip.TabIndex = 14
        Me.txt25PctTip.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Form1
        '
        Me.AcceptButton = Me.btnCalculate
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 211)
        Me.Controls.Add(Me.txt25PctTotal)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txt25PctTip)
        Me.Controls.Add(Me.txt20PctTotal)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txt20PctTip)
        Me.Controls.Add(Me.txt15PctTotal)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txt15PctTip)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txt10PctTotal)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txt10PctTip)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.txtAmount)
        Me.Name = "Form1"
        Me.Text = "Declaring Variables and Performing Calculations"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtAmount As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txt10PctTip As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txt10PctTotal As System.Windows.Forms.TextBox
    Friend WithEvents txt15PctTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txt15PctTip As System.Windows.Forms.TextBox
    Friend WithEvents txt20PctTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txt20PctTip As System.Windows.Forms.TextBox
    Friend WithEvents txt25PctTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txt25PctTip As System.Windows.Forms.TextBox

End Class
