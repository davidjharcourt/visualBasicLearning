﻿Public Class Form1
    ' Display the PrintPreviewDialog.
    Private Sub btnPrint_Click(sender As Object, e As EventArgs) Handles btnPrint.Click
        ppdManyPages.ShowDialog()
    End Sub

    ' The number of the next page to display.
    Private NextPage As Integer = 1

    ' Generate pages.
    Private Sub pdocManyPages_PrintPage(sender As Object, e As Drawing.Printing.PrintPageEventArgs) Handles pdocManyPages.PrintPage
        ' Draw smoothly.
        e.Graphics.SmoothingMode = Drawing2D.SmoothingMode.AntiAlias

        ' Get the number of pages we're creating.
        Dim num_pages As Integer = txtNumPages.Text

        ' Calculate the positions of the quadrants.
        Dim xmin As Integer = e.MarginBounds.Left
        Dim xmax As Integer = e.MarginBounds.Right
        Dim xmid As Integer = (xmin + xmax) / 2
        Dim ymin As Integer = e.MarginBounds.Top
        Dim ymax As Integer = e.MarginBounds.Bottom
        Dim ymid As Integer = (ymin + ymax) / 2

        ' Get the quadrants' widths and heights.
        Dim wid As Integer = xmid - xmin
        Dim hgt As Integer = ymid - ymin

        ' Draw the rectangle.
        e.Graphics.FillRectangle(Brushes.Blue, xmin, ymin, wid, hgt)

        ' Draw the ellipse.
        e.Graphics.FillEllipse(Brushes.Red, xmid, ymin, wid, hgt)

        ' Draw the triangle.
        Dim triangle_points() As Point =
            {
                New Point(xmin, ymax),
                New Point(xmin + wid / 2, ymid),
                New Point(xmid, ymax)
            }
        e.Graphics.FillPolygon(Brushes.Green, triangle_points)

        ' Draw the diamond.
        Dim diamond_points() As Point =
            {
                New Point(xmid + wid / 2, ymid),
                New Point(xmax, ymid + hgt / 2),
                New Point(xmid + wid / 2, ymax),
                New Point(xmid, ymid + hgt / 2)
            }
        e.Graphics.FillPolygon(Brushes.Orange, diamond_points)

        ' Increment the page number.
        NextPage += 1

        ' See if we're done.
        If NextPage > num_pages Then
            ' We're done.
            e.HasMorePages = False
            NextPage = 1
        Else
            ' We're not done.
            e.HasMorePages = True
        End If
    End Sub
End Class
